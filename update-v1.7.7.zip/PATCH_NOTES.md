# V1.7.7 真正修正 9/9 停滯問題

V1.7.6 的問題已重新檢查。

真正原因有兩層：
1. Yahoo Chart 日 K 可能晚於 Yahoo 台股網頁更新，因此 Yahoo 網頁已有 9/10，Chart API 仍可能停在 9/9。
2. V1.7.6 嘗試用 TWSE STOCK_DAY_ALL 補今天，但 STOCK_DAY_ALL 本身沒有交易日期欄位。
   把該列直接標成伺服器的「today」在跨午夜時是不可靠的，也不是嚴格資料審計做法。

V1.7.7 改法：
- 個股頁查歷史資料時新增 fresh=1。
- Yahoo 仍提供長期歷史 K。
- fresh=1 時，再抓 TWSE 官方 STOCK_DAY 月資料。
- STOCK_DAY 每一列都有明確民國日期，因此可以精確轉成 YYYY-MM-DD。
- 用 TWSE 最近約 45 天「精確日期」資料覆蓋/補齊 Yahoo 最近資料。
- 不再用現在時間猜股票交易日。
- 如果 TWSE 最新列是 2026-09-10，就會真正得到 2026-09-10。
- 若 9/10 尚未出現在官方資料，系統才保留最後實際存在的交易日。

效能：
- 只有個股頁 fresh=1 才做這個官方補齊。
- 大盤 195 檔初篩不會每檔多打一個 TWSE monthly request，因此不拖慢全市場掃描。

掃描頁：
只保留四個使用者需要的排行：
- Setup
- Opportunity
- Entry
- Hold
其餘 Bottom / Ignition / Trend / Persistence 仍是模型內部因子，不獨立顯示排行。
