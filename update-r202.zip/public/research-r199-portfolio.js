/* Chronological cash-account simulation. No selection using future returns. */
(function(root){
'use strict';
function config(p={}){
 const initial=p.initial??1000000,maxPositions=p.maxPositions??5,lotSize=p.lotSize??1000;
 if(!Number.isFinite(initial)||initial<=0||initial>1e12||!Number.isInteger(maxPositions)||maxPositions<1||maxPositions>100||![1,1000].includes(lotSize))throw Error('資金須為正數；持倉上限1–100檔；交易單位1或1000股');
 return {initial,maxPositions,lotSize};
}
function run(C,data,rows,p,range,cost,settings){
 const equal=settings?.mode==='equal',ids=settings?.ids||[],perStock=settings?.perStock||100000;
 if(equal&&!ids.length)throw Error('等額模式需要固定股票名單');
 const cfg=config(equal?{initial:perStock*ids.length,maxPositions:100,lotSize:1}:settings),wallet=new Map(ids.map(id=>[id,perStock])),first=data.dates.indexOf(range[0]),last=data.dates.indexOf(range[1]),entryLast=p.maxHold===0?last-1:last-26;
 if(first<0||last<first)throw Error('帳戶模擬期間無效');
 const signals=new Map();for(const r of rows)if(r.di>=first&&r.di<=last){if(!signals.has(r.di))signals.set(r.di,new Map());signals.get(r.di).set(C.key(r),r);}
 let cash=cfg.initial,peak=cfg.initial,maxDrawdown=0,maxDrawdownMoney=0,maxInvested=0,skippedFunds=0,skippedSlots=0,unfilled=0,staleMarks=0,liquidityBlocked=0;
 const held=new Map(),trades=[],curve=[];let pendingBuys=[];
 const invested=()=>[...held.values()].reduce((s,x)=>s+x.outlay,0);
 for(let di=first;di<=last;di++){
  const date=data.dates[di],bars=data.daily.get(date)||new Map(),today=signals.get(di)||new Map();
  // Sell orders raised at an earlier close are processed before buys, same open.
  for(const [id,pos] of [...held].sort((a,b)=>a[0].localeCompare(b[0]))){
   if(!pos.exit)continue;const bar=bars.get(id);if(!C.executable(bar)){unfilled++;continue;}
   const price=bar.open*(1-cost.slippage),proceeds=pos.shares*price*(1-cost.fee-cost.tax),pnl=proceeds-pos.outlay;
   cash+=proceeds;if(equal)wallet.set(id,wallet.get(id)+proceeds);trades.push({id,signalDate:pos.signalDate,entryDate:pos.entryDate,exitSignalDate:pos.exit.date,exitDate:date,shares:pos.shares,buyPrice:pos.buyPrice,sellPrice:price,buyOutlay:pos.outlay,sellProceeds:proceeds,pnl,net:pnl/pos.outlay*100,holdingDays:di-pos.di,reason:pos.exit.reason});held.delete(id);
  }
  pendingBuys.sort((a,b)=>b.score-a.score||a.id.localeCompare(b.id));
  for(const order of pendingBuys){
   if(held.has(order.id))continue;
   if(!equal&&held.size>=cfg.maxPositions){skippedSlots++;continue;}
   const bar=bars.get(order.id);if(!C.executable(bar)){unfilled++;continue;}
   const price=bar.open*(1+cost.slippage),perShare=price*(1+cost.fee),budget=equal?(wallet.get(order.id)||0):Math.min(cfg.initial/cfg.maxPositions,cash);
   const shares=equal?budget/perShare:Math.floor(budget/perShare/cfg.lotSize)*cfg.lotSize;
   if(equal?shares<=0:shares<cfg.lotSize){skippedFunds++;continue;}
   const outlay=shares*perShare;cash-=outlay;if(equal)wallet.set(order.id,Math.max(0,wallet.get(order.id)-outlay));
   held.set(order.id,{shares,outlay,buyPrice:price,entryDate:date,signalDate:order.date,di,lastClose:bar.open,exit:null});maxInvested=Math.max(maxInvested,invested());
  }
  pendingBuys=[];
  for(const [id,pos] of held){
   if(!pos.exit){const r=today.get(id),score=r?C.weightsScore(r,p.exit):null,timed=p.maxHold>0&&di-pos.di+1>=p.maxHold;
    if(timed||(score!==null&&score>=p.exitThreshold))pos.exit={date,reason:timed?'maxHold':'score'};
   }
  }
  if(di<=entryLast)for(const [id,r] of today){if(held.has(id)||!r.rank)continue;const score=C.weightsScore(r,p.entry);if(score===null||score<p.entryThreshold)continue;if(!C.liquidEntry(r,p)){liquidityBlocked++;continue;}pendingBuys.push({id,date,score});}
  let marketValue=0;for(const [id,pos] of held){const bar=bars.get(id);if(bar&&Number.isFinite(bar.close)&&bar.close>0)pos.lastClose=bar.close;else staleMarks++;marketValue+=pos.shares*pos.lastClose;}
  const equity=cash+marketValue;peak=Math.max(peak,equity);const dd=peak-equity;maxDrawdown=Math.max(maxDrawdown,dd/peak*100);maxDrawdownMoney=Math.max(maxDrawdownMoney,dd);
  curve.push({date,cash,marketValue,equity,roi:(equity/cfg.initial-1)*100,positions:held.size,drawdown:dd/peak*100});
 }
 const positive=trades.filter(t=>t.pnl>0),negative=trades.filter(t=>t.pnl<0),avg=a=>a.length?a.reduce((s,t)=>s+t.pnl,0)/a.length:null;
 const avgWin=avg(positive),avgLoss=avg(negative),finalEquity=curve.at(-1).equity,monthly=[];
 let previous=cfg.initial;const months=new Map();for(const r of curve)months.set(r.date.slice(0,7),r);
 for(const [month,row] of months){monthly.push({month,returnPct:(row.equity/previous-1)*100,pnl:row.equity-previous,endEquity:row.equity});previous=row.equity;}
 return {model:equal?'equal-stock-fractional-r20':'cash-account-daily-close-r19.9',stockResults:equal?ids.map(id=>({id,initial:perStock,finalEquity:wallet.get(id)+(held.has(id)?held.get(id).shares*held.get(id).lastClose:0),trades:trades.filter(t=>t.id===id).length})):undefined,settings:cfg,range,initial:cfg.initial,finalEquity,netProfit:finalEquity-cfg.initial,roi:(finalEquity/cfg.initial-1)*100,maxDrawdown,maxDrawdownMoney,maxInvested,win:trades.length?positive.length/trades.length*100:null,n:trades.length,wins:positive.length,losses:negative.length,breakeven:trades.length-positive.length-negative.length,avgWin,avgLoss,payoffRatio:avgLoss<0?avgWin/Math.abs(avgLoss):null,skippedFunds,skippedSlots,unfilled,liquidityBlocked,unresolved:held.size,staleMarks,holdings:[...held].map(([id,x])=>({id,shares:x.shares,entryDate:x.entryDate,outlay:x.outlay,lastClose:x.lastClose,marketValue:x.shares*x.lastClose})),curve,monthly,trades};
}
function benchmark(portfolio,rows,baseDate){
 if(!portfolio)return {ok:false,error:'尚無帳戶模擬結果'};
 const map=new Map();for(const r of rows||[]){if(map.has(r.date)||!/^\d{4}-\d{2}-\d{2}$/.test(r.date)||!Number.isFinite(r.close)||r.close<=0)return {ok:false,error:'大盤資料含重複日期或無效數值'};map.set(r.date,r.close);}
 if(!map.has(baseDate))return {ok:false,error:'缺少測試開始前一交易日大盤收盤值，無法比較'};
 const missing=portfolio.curve.filter(r=>!map.has(r.date)).map(r=>r.date);if(missing.length)return {ok:false,error:`大盤缺 ${missing.length} 個比較日期；不補值或縮短比較期間`,missing};
 const base=map.get(baseDate),curve=[];let peak=portfolio.initial,maxDrawdown=0;
 for(const r of portfolio.curve){const equity=portfolio.initial*map.get(r.date)/base;peak=Math.max(peak,equity);maxDrawdown=Math.max(maxDrawdown,(peak-equity)/peak*100);curve.push({date:r.date,equity,roi:(equity/portfolio.initial-1)*100});}
 const roi=curve.at(-1).roi;const monthly=[];let prior=portfolio.initial;const months=new Map();for(const r of curve)months.set(r.date.slice(0,7),r);
 for(const [month,r] of months){monthly.push({month,returnPct:(r.equity/prior-1)*100});prior=r.equity;}
 return {ok:true,baseDate,roi,maxDrawdown,netProfit:curve.at(-1).equity-portfolio.initial,excessReturn:portfolio.roi-roi,drawdownAdvantage:maxDrawdown-portfolio.maxDrawdown,curve,monthly,returnType:'TAIEX price index; no dividends or costs'};
}
const api={config,run,benchmark};if(typeof module!=='undefined')module.exports=api;root.ResearchPortfolio=api;
})(typeof globalThis!=='undefined'?globalThis:this);
