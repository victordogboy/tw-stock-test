const JSON_HEADERS = {
  "content-type": "application/json; charset=utf-8",
  "cache-control": "no-store",
};

const CORS = {
  "access-control-allow-origin": "*",
  "access-control-allow-methods": "GET,OPTIONS",
  "access-control-allow-headers": "Content-Type,Authorization",
};

function json(data, status = 200, extra = {}) {
  return new Response(JSON.stringify(data, null, 2), {
    status,
    headers: { ...JSON_HEADERS, ...CORS, ...extra },
  });
}

async function fetchJson(url, init = {}) {
  const r = await fetch(url, {
    ...init,
    headers: {
      "accept": "application/json,text/plain,*/*",
      "user-agent": "tw-stock-api/1.0",
      ...(init.headers || {}),
    },
  });

  const text = await r.text();
  let body;
  try {
    body = JSON.parse(text);
  } catch {
    body = null;
  }

  if (!r.ok) {
    throw new Error(`Upstream ${r.status}: ${text.slice(0, 300)}`);
  }
  if (body === null) {
    throw new Error(`Upstream returned non-JSON: ${text.slice(0, 300)}`);
  }
  return body;
}

function normalizeTwse(rows) {
  if (!Array.isArray(rows)) return [];
  return rows.map(x => ({
    market: "twse",
    code: String(x.Code ?? x.code ?? "").trim(),
    name: String(x.Name ?? x.name ?? "").trim(),
    close: Number(String(x.ClosingPrice ?? x.Close ?? x.close ?? "").replace(/,/g, "")),
    change: Number(String(x.Change ?? x.change ?? "").replace(/,/g, "")),
    volume_shares: Number(String(x.TradeVolume ?? x.Trading_Volume ?? x.volume ?? "").replace(/,/g, "")),
    turnover: Number(String(x.TradeValue ?? x.turnover ?? "").replace(/,/g, "")),
    open: Number(String(x.OpeningPrice ?? x.Open ?? x.open ?? "").replace(/,/g, "")),
    high: Number(String(x.HighestPrice ?? x.High ?? x.high ?? "").replace(/,/g, "")),
    low: Number(String(x.LowestPrice ?? x.Low ?? x.low ?? "").replace(/,/g, "")),
    raw: x,
  })).filter(x => x.code);
}



async function fetchTpexUniverse(){
  const urls=["https://isin.twse.com.tw/isin/C_public.jsp?strMode=4"];
  const attempts=[];
  for(const u of urls){
    try{
      const r=await fetch(u,{headers:{"accept":"text/html,*/*","user-agent":"Mozilla/5.0 (compatible; tw-stock-api/1.14.2)"}});
      const buf=await r.arrayBuffer();
      const utf8=new TextDecoder("utf-8",{fatal:false}).decode(buf);
      let big5="";
      try{big5=new TextDecoder("big5",{fatal:false}).decode(buf)}catch{}
      const bad=s=>(s.match(/�/g)||[]).length;
      const chinese=s=>(s.match(/[一-龥]/g)||[]).length;
      const text=(big5&&(bad(big5)<bad(utf8)||chinese(big5)>chinese(utf8)*1.25))?big5:utf8;
      attempts.push({url:u,status:r.status,bytes:buf.byteLength,encoding:text===big5?"big5":"utf-8"});
      if(!r.ok||text.length<1000) continue;
      const out=new Map();
      for(const m of text.matchAll(/<td[^>]*>\s*(\d{4})[\s\u3000]*(?:&nbsp;)*\s*([^<\r\n]+?)\s*<\/td>/gi)){
        const code=m[1],name=m[2].replace(/&nbsp;/g," ").trim();
        if(!code.startsWith("00")&&name) out.set(code,{market:"tpex",code,name});
      }
      const cells=[...text.matchAll(/<td[^>]*>([\s\S]*?)<\/td>/gi)].map(m=>m[1].replace(/<[^>]+>/g," ").replace(/&nbsp;/g," ").replace(/\s+/g," ").trim());
      for(let i=0;i<cells.length-1;i++) if(/^\d{4}$/.test(cells[i])&&!cells[i].startsWith("00")){
        const name=cells[i+1]; if(name&&!/^\d/.test(name)) out.set(cells[i],{market:"tpex",code:cells[i],name});
      }
      if(out.size>300) return {ok:true,data:[...out.values()],source:"TWSE ISIN OTC universe",upstream:u,attempts};
    }catch(e){attempts.push({url:u,error:String(e?.message||e)})}
  }
  return {ok:false,data:[],source:"TWSE ISIN OTC universe",attempts,error:"Unable to obtain OTC universe"};
}

async function fetchTpexAll() {
  const attempts = [];

  // Strategy A: official OpenAPI endpoints
  const openapiCandidates = [
    "https://www.tpex.org.tw/openapi/v1/tpex_mainboard_daily_close_quotes",
    "https://www.tpex.org.tw/openapi/v1/tpex_mainboard_quotes"
  ];

  for (const u of openapiCandidates) {
    try {
      const r = await fetch(u, {
        redirect: "manual",
        headers: {
          "accept": "application/json",
          "user-agent": "Mozilla/5.0 (compatible; tw-stock-api/1.2)"
        }
      });
      const location = r.headers.get("location");
      attempts.push({strategy:"openapi",url:u,status:r.status,location});
      if (r.status >= 300 && r.status < 400) continue;
      if (!r.ok) continue;
      const text = await r.text();
      try {
        const body = JSON.parse(text);
        if (Array.isArray(body) && body.length) {
          return { ok:true, raw:body, upstream:u, attempts, mode:"openapi" };
        }
      } catch {}
    } catch(e) {
      attempts.push({strategy:"openapi",url:u,error:String(e?.message||e)});
    }
  }

  // Strategy B: TPEx official webpage JSON interface.
  // The public Daily Stock Quotes page is still available and exposes data
  // through its webpage backend. Try current-date and empty-date forms.
  const today = new Date().toLocaleDateString("sv-SE", { timeZone: "Asia/Taipei" });
  const webpageCandidates = [
    `https://www.tpex.org.tw/www/zh-tw/mainboard/trading/info/pricing?date=${today}&id=&response=json`,
    `https://www.tpex.org.tw/www/zh-tw/mainboard/trading/info/pricing?date=&id=&response=json`,
    `https://www.tpex.org.tw/zh-tw/mainboard/trading/info/pricing.html?date=${today}&id=&response=json`,
    `https://www.tpex.org.tw/zh-tw/mainboard/trading/info/pricing.html?date=&id=&response=json`
  ];

  for (const u of webpageCandidates) {
    try {
      const r = await fetch(u, {
        redirect: "manual",
        headers: {
          "accept": "application/json,text/plain,*/*",
          "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36",
          "referer": "https://www.tpex.org.tw/zh-tw/mainboard/trading/info/pricing.html"
        }
      });
      const location = r.headers.get("location");
      attempts.push({strategy:"webpage-json",url:u,status:r.status,location,contentType:r.headers.get("content-type")});
      if (r.status >= 300 && r.status < 400) continue;
      if (!r.ok) continue;
      const text = await r.text();

      let body;
      try { body = JSON.parse(text); } catch { body = null; }
      if (!body) continue;

      // Known TPEx webpage JSON payloads commonly wrap tables under tables[]
      // with rows stored in data / rows.
      const candidates = [];
      if (Array.isArray(body)) candidates.push(body);
      if (Array.isArray(body.data)) candidates.push(body.data);
      if (Array.isArray(body.rows)) candidates.push(body.rows);
      if (Array.isArray(body.tables)) {
        for (const t of body.tables) {
          if (Array.isArray(t?.data)) candidates.push(t.data);
          if (Array.isArray(t?.rows)) candidates.push(t.rows);
        }
      }

      for (const arr of candidates) {
        if (arr.length) {
          return {
            ok:true,
            raw:arr,
            upstream:u,
            attempts,
            mode:"webpage-json",
            payload_meta:{
              topKeys:Object.keys(body).slice(0,20),
              tableCount:Array.isArray(body.tables)?body.tables.length:null
            }
          };
        }
      }
    } catch(e) {
      attempts.push({strategy:"webpage-json",url:u,error:String(e?.message||e)});
    }
  }

  return { ok:false, raw:[], upstream:null, attempts };
}

function normalizeTpex(rows) {
  if (!Array.isArray(rows)) return [];

  return rows.map(x => {
    // Object-form rows from OpenAPI
    if (!Array.isArray(x)) {
      const code = x.SecuritiesCompanyCode ?? x.SecuritiesCode ?? x.Code ?? x.code ?? x["代號"] ?? "";
      const name = x.CompanyName ?? x.SecuritiesName ?? x.Name ?? x.name ?? x["名稱"] ?? "";
      const close = x.Close ?? x.ClosePrice ?? x.ClosingPrice ?? x.close ?? x["收盤"] ?? "";
      const vol = x.TradingShares ?? x.TradingVolume ?? x.TradeVolume ?? x.Volume ?? x.volume ?? x["成交股數"] ?? "";
      return {
        market:"tpex",
        code:String(code).trim(),
        name:String(name).trim(),
        close:Number(String(close).replace(/,/g,"").replace(/--/g,"")),
        volume_shares:Number(String(vol).replace(/,/g,"").replace(/--/g,"")),
        raw:x
      };
    }

    // Array-form rows from TPEx webpage tables.
    // Typical order begins with code, name, close/change, open/high/low, volume...
    // We infer code/name by content and infer numeric fields defensively.
    const vals=x.map(v=>String(v??"").trim());
    let code="", name="";
    for (let i=0;i<Math.min(vals.length,4);i++) {
      if (!code && /^\d{4}$/.test(vals[i])) {
        code=vals[i];
        if (i+1<vals.length) name=vals[i+1];
        break;
      }
    }

    const nums=vals.map(v=>{
      const z=v.replace(/,/g,"").replace(/--/g,"").replace(/[+]/g,"");
      return /^-?\d+(\.\d+)?$/.test(z)?Number(z):NaN;
    });

    // Heuristic:
    // first plausible price after code/name = close;
    // largest integer-like number later in row = volume shares.
    let close=NaN;
    for (let i=2;i<nums.length;i++) {
      if (Number.isFinite(nums[i]) && nums[i]>0 && nums[i]<100000) { close=nums[i]; break; }
    }
    let volume=NaN;
    const numericCandidates=nums.filter(n=>Number.isFinite(n) && n>=0);
    if (numericCandidates.length) volume=Math.max(...numericCandidates.filter(n=>Number.isInteger(n)));

    return {market:"tpex",code,name,close,volume_shares:volume,raw:x};
  }).filter(x=>x.code);
}

function ordinaryStock(x) {
  return /^\d{4}$/.test(x.code) && !x.code.startsWith("00");
}


function unixSec(dateStr) {
  return Math.floor(new Date(dateStr + "T00:00:00+08:00").getTime()/1000);
}

function taipeiSessionState(){
  const parts=new Intl.DateTimeFormat("en-CA",{
    timeZone:"Asia/Taipei",
    year:"numeric",month:"2-digit",day:"2-digit",
    hour:"2-digit",minute:"2-digit",hour12:false
  }).formatToParts(new Date());
  const o={}; for(const p of parts)o[p.type]=p.value;
  const date=`${o.year}-${o.month}-${o.day}`;
  const minutes=Number(o.hour)*60+Number(o.minute);
  return {date,minutes,is_open:minutes>=540&&minutes<810};
}
function isoDateTaipei(d=new Date()) {
  return new Intl.DateTimeFormat("sv-SE", {timeZone:"Asia/Taipei"}).format(d);
}
function addDaysISO(dateStr, days) {
  const d=new Date(dateStr+"T12:00:00+08:00");
  d.setUTCDate(d.getUTCDate()+days);
  return d.toISOString().slice(0,10);
}
function yyyymmdd(dateStr){ return String(dateStr).replaceAll("-",""); }


async function mergeTwseLatestBar(code, market, endDate, history){
  // Yahoo daily chart can lag the TWSE same-day close even after the TWSE quote is final.
  // For listed stocks, use official TWSE STOCK_DAY_ALL as the same-day source of truth.
  if(market==="tpex") return {data:history,merged:false};
  const today=isoDateTaipei();
  if(endDate < today) return {data:history,merged:false};

  try{
    const raw=await fetchJson("https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL");
    const rows=normalizeTwse(raw);
    const q=rows.find(x=>String(x.code)===String(code));
    if(!q || !Number.isFinite(q.close) || !Number.isFinite(q.open) ||
       !Number.isFinite(q.high) || !Number.isFinite(q.low) ||
       !Number.isFinite(q.volume_shares) || q.volume_shares<=0){
      return {data:history,merged:false};
    }

    const bar={
      date:today,
      open:q.open,
      high:q.high,
      low:q.low,
      close:q.close,
      adj_close:q.close,
      volume:q.volume_shares,
      symbol:String(code)+".TW",
      source:"TWSE STOCK_DAY_ALL"
    };

    const data=[...history];
    const i=data.findIndex(x=>x.date===today);
    if(i>=0) data[i]=bar;
    else data.push(bar);
    data.sort((a,b)=>a.date.localeCompare(b.date));

    return {data,merged:true,twse_bar:bar};
  }catch(e){
    return {data:history,merged:false,merge_error:String(e?.message||e)};
  }
}

async function fetchYahooHistory(code, market, startDate, endDate) {
  const suffixes = market==="tpex" ? [".TWO",".TW"] :
                   market==="twse" ? [".TW",".TWO"] :
                   [".TW",".TWO"];
  const attempts=[];
  const p1=unixSec(startDate);
  const p2=unixSec(addDaysISO(endDate,1));
  for(const suffix of suffixes){
    const symbol=code+suffix;
    for(const host of ["query1.finance.yahoo.com","query2.finance.yahoo.com"]){
      const u=`https://${host}/v8/finance/chart/${encodeURIComponent(symbol)}?period1=${p1}&period2=${p2}&interval=1d&events=history&includeAdjustedClose=true`;
      try{
        const r=await fetch(u,{headers:{
          "accept":"application/json,text/plain,*/*",
          "user-agent":"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36"
        }});
        attempts.push({source:"yahoo",host,symbol,status:r.status});
        if(!r.ok) continue;
        const j=await r.json();
        const z=j?.chart?.result?.[0];
        const ts=z?.timestamp||[];
        const q=z?.indicators?.quote?.[0]||{};
        const adj=z?.indicators?.adjclose?.[0]?.adjclose||[];
        if(!ts.length) continue;
        const data=ts.map((t,i)=>({
          date:new Date(t*1000).toISOString().slice(0,10),
          open:roundTwPrice(q.open?.[i]),
          high:roundTwPrice(q.high?.[i]),
          low:roundTwPrice(q.low?.[i]),
          close:roundTwPrice(q.close?.[i]),
          adj_close:adj?.[i]??null,
          volume:q.volume?.[i]??null,
          symbol
        })).filter(x=>Number.isFinite(x.close) && x.close>0);
        if(data.length) return {ok:true,source:"Yahoo Finance chart",symbol,data,attempts};
      }catch(e){
        attempts.push({source:"yahoo",host,symbol,error:String(e?.message||e)});
      }
    }
  }
  return {ok:false,source:"Yahoo Finance chart",data:[],attempts};
}

function rocToIso(s){
  const m=String(s||"").match(/(\d{3})\/(\d{2})\/(\d{2})/);
  if(!m) return null;
  return `${Number(m[1])+1911}-${m[2]}-${m[3]}`;
}
function numTW(v){
  if(v===null||v===undefined||v==='') return null;
  const s=String(v).replaceAll(",","").replaceAll("--","").trim();
  if(!s) return null;
  const n=Number(s);
  return Number.isFinite(n)?n:null;
}

function twTickSize(price){
  const p=Number(price);
  if(!Number.isFinite(p) || p<=0) return 0.01;
  if(p<10) return 0.01;
  if(p<50) return 0.05;
  if(p<100) return 0.1;
  if(p<500) return 0.5;
  if(p<1000) return 1;
  return 5;
}
function roundTwPrice(price){
  if(price===null||price===undefined||price==='') return null;
  const p=Number(price);
  if(!Number.isFinite(p)) return null;
  const tick=twTickSize(p);
  const v=Math.round(p/tick)*tick;
  return Number(v.toFixed(tick<0.1?2:tick<1?1:0));
}

function twseMisNumber(value,{allowZero=false}={}){
  if(value===null||value===undefined||value===''||value==='-')return null;
  const n=Number(String(value).replaceAll(',',''));
  return Number.isFinite(n)&&(allowZero?n>=0:n>0)?n:null;
}

function intradayValidationErrors(bar){
  const errors=[];
  for(const key of ['open','high','low','close']){
    const value=Number(bar?.[key]);
    if(!Number.isFinite(value)||value<=0)errors.push(`${key} missing/invalid`);
  }
  const {open,high,low,close}=bar||{};
  if(Number.isFinite(low)&&Number.isFinite(high)&&low>high)errors.push('low > high');
  if(Number.isFinite(open)&&Number.isFinite(high)&&open>high*1.002)errors.push('open > high');
  if(Number.isFinite(open)&&Number.isFinite(low)&&open<low*.998)errors.push('open < low');
  if(Number.isFinite(close)&&Number.isFinite(high)&&close>high*1.002)errors.push('close > high');
  if(Number.isFinite(close)&&Number.isFinite(low)&&close<low*.998)errors.push('close < low');
  const prevClose=Number(bar?.prev_close);
  if(Number.isFinite(prevClose)&&prevClose>0&&Number.isFinite(close)){
    const ratio=close/prevClose;
    if(ratio<0.2||ratio>5)errors.push(`price scale anomaly ratio=${ratio.toFixed(3)}`);
  }
  return errors;
}

async function fetchTwseMisIntraday(code,market,attempts){
  const exchanges=market==='tpex'?['otc','tse']:market==='twse'?['tse','otc']:['tse','otc'];
  for(const exchange of exchanges){
    const channel=`${exchange}_${code}.tw`;
    try{
      const upstream=`https://mis.twse.com.tw/stock/api/getStockInfo.jsp?ex_ch=${encodeURIComponent(channel)}&json=1&delay=0&_=${Date.now()}`;
      const response=await fetch(upstream,{
        headers:{
          accept:'application/json,text/plain,*/*',
          referer:'https://mis.twse.com.tw/stock/index.jsp',
          'user-agent':'Mozilla/5.0 (compatible; tw-stock-api/1.17)'
        },
        signal:AbortSignal.timeout(6000)
      });
      const attempt={source:'TWSE MIS',host:'mis.twse.com.tw',channel,status:response.status};
      attempts.push(attempt);
      if(!response.ok)continue;
      const payload=await response.json();
      const row=(Array.isArray(payload?.msgArray)?payload.msgArray:[])
        .find(x=>String(x?.c||'').trim()===String(code));
      if(!row){attempt.error='stock not found on channel';continue}

      const closeRaw=twseMisNumber(row.z)??twseMisNumber(row.trade?.z)??twseMisNumber(row.pz);
      if(closeRaw===null){attempt.error='latest trade price unavailable';continue}
      const openRaw=twseMisNumber(row.o)??closeRaw;
      const highRaw=Math.max(...[twseMisNumber(row.h),openRaw,closeRaw].filter(Number.isFinite));
      const lowRaw=Math.min(...[twseMisNumber(row.l),openRaw,closeRaw].filter(Number.isFinite));
      const dateRaw=String(row.d||row['^']||'').replace(/\D/g,'');
      if(!/^\d{8}$/.test(dateRaw)){attempt.error='invalid quote date';continue}
      const date=`${dateRaw.slice(0,4)}-${dateRaw.slice(4,6)}-${dateRaw.slice(6,8)}`;
      const lastTime=String(row.t||row['%']||row.trade?.t||'').trim();
      const time=/^\d{2}:\d{2}:\d{2}$/.test(lastTime)?lastTime:null;
      const millis=twseMisNumber(row.tlong);
      const lastTimestamp=millis!==null
        ?Math.floor(millis/1000)
        :(time?Math.floor(new Date(`${date}T${time}+08:00`).getTime()/1000):null);
      const prevCloseRaw=twseMisNumber(row.y);
      const close=roundTwPrice(closeRaw),prevClose=roundTwPrice(prevCloseRaw);
      const lots=twseMisNumber(row.v,{allowZero:true})??0;
      const bar={
        date,
        open:roundTwPrice(openRaw),
        high:roundTwPrice(highRaw),
        low:roundTwPrice(lowRaw),
        close,
        volume:Math.round(lots*1000),
        last_time:time,
        last_timestamp:lastTimestamp,
        prev_close:prevClose,
        change:Number.isFinite(prevClose)?roundTwPrice(close-prevClose):null,
        change_pct:Number.isFinite(prevClose)&&prevClose!==0?(close-prevClose)/prevClose*100:null,
        symbol:`${code}.${exchange==='otc'?'TWO':'TW'}`
      };
      const validationErrors=intradayValidationErrors(bar);
      if(validationErrors.length){attempt.validation_errors=validationErrors;continue}
      const session=taipeiSessionState();
      return {
        ok:true,
        quote_valid:true,
        validation_errors:[],
        source:'TWSE MIS official realtime fallback',
        symbol:bar.symbol,
        bar,
        points:1,
        attempts,
        market_state:session.is_open?'REGULAR':'CLOSED',
        session_open:session.is_open&&date===session.date,
        session_date:session.date,
        fallback_from:'Yahoo Finance 1m intraday'
      };
    }catch(e){
      attempts.push({source:'TWSE MIS',host:'mis.twse.com.tw',channel,error:String(e?.message||e)});
    }
  }
  return null;
}
async function fetchTwseMonthlyHistory(code,startDate,endDate){
  const attempts=[], rows=[];
  let cursor=new Date(startDate.slice(0,7)+"-01T12:00:00+08:00");
  const endM=new Date(endDate.slice(0,7)+"-01T12:00:00+08:00");
  while(cursor<=endM){
    const ds=cursor.toISOString().slice(0,10).replaceAll("-","");
    const u=`https://www.twse.com.tw/rwd/zh/afterTrading/STOCK_DAY?date=${ds}&stockNo=${encodeURIComponent(code)}&response=json&_=${Date.now()}`;
    try{
      const r=await fetch(u,{headers:{
        "accept":"application/json,text/plain,*/*",
        "user-agent":"Mozilla/5.0 (compatible; tw-stock-api/1.3)"
      }});
      attempts.push({source:"twse-monthly",month:ds.slice(0,6),status:r.status});
      if(r.ok){
        const j=await r.json();
        if(Array.isArray(j.data)){
          for(const a of j.data){
            const date=rocToIso(a?.[0]);
            if(!date) continue;
            rows.push({
              date,
              volume:numTW(a?.[1]),
              turnover:numTW(a?.[2]),
              open:numTW(a?.[3]),
              high:numTW(a?.[4]),
              low:numTW(a?.[5]),
              close:numTW(a?.[6]),
              change:numTW(String(a?.[7]??"").replace("+","")),
              trades:numTW(a?.[8])
            });
          }
        }
      }
    }catch(e){attempts.push({source:"twse-monthly",month:ds.slice(0,6),error:String(e?.message||e)})}
    cursor.setMonth(cursor.getMonth()+1);
  }
  const map=new Map(rows.filter(x=>x.date>=startDate&&x.date<=endDate&&Number.isFinite(x.close)&&x.close>0).map(x=>[x.date,x]));
  const data=[...map.values()].sort((a,b)=>a.date.localeCompare(b.date));
  return {ok:data.length>0,source:"TWSE STOCK_DAY monthly",data,attempts};
}



async function mergeTwseExactRecentBars(code,startDate,endDate,history){
  // IMPORTANT: STOCK_DAY_ALL does not carry the trading date.
  // Never stamp it with server "today", especially around midnight.
  // Instead use TWSE STOCK_DAY monthly data because every row contains its exact ROC trading date.
  try{
    const recentStart=addDaysISO(endDate,-45);
    const twse=await fetchTwseMonthlyHistory(code,recentStart,endDate);
    if(!twse.ok || !twse.data.length){
      return {data:history,merged:0,source:"Yahoo only",attempts:twse.attempts||[]};
    }
    const map=new Map((history||[]).map(x=>[x.date,x]));
    let merged=0;
    for(const row of twse.data){
      const old=map.get(row.date);
      // Official TWSE wins for overlapping recent listed-stock bars.
      if(!old || old.open!==row.open || old.high!==row.high || old.low!==row.low ||
         old.close!==row.close || old.volume!==row.volume){
        merged++;
      }
      map.set(row.date,{...old,...row,source:"TWSE STOCK_DAY monthly"});
    }
    const data=[...map.values()]
      .filter(x=>x.date>=startDate && x.date<=endDate)
      .sort((a,b)=>a.date.localeCompare(b.date));
    return {
      data,
      merged,
      source:"Yahoo history + TWSE exact-date recent bars",
      last_twse:twse.data.at(-1)?.date||null,
      attempts:twse.attempts||[]
    };
  }catch(e){
    return {data:history,merged:0,source:"Yahoo only",error:String(e?.message||e)};
  }
}

function twDateCompact(iso){ return String(iso||"").replaceAll("-",""); }
function recentWeekdays(endIso,count){
  const out=[]; let d=new Date(endIso+"T12:00:00+08:00");
  while(out.length<count){
    const wd=d.getDay();
    if(wd!==0&&wd!==6) out.push(d.toISOString().slice(0,10));
    d.setDate(d.getDate()-1);
  }
  return out;
}
function cleanNum(v){
  if(v===null||v===undefined)return null;
  const raw=String(v).trim();
  if(!raw||raw==="--"||raw==="-"||raw==="—")return null;
  const s=raw.replaceAll(",","").replaceAll("+","");
  const n=Number(s); return Number.isFinite(n)?n:null;
}
function rowByFields(payload,code){
  // TWSE RWD responses are not uniform:
  // some reports return top-level {fields,data}; others return {tables:[{fields,data}]}.
  // R5 only parsed tables[], which made valid official data look missing (0% completeness).
  const tables=[];
  if(Array.isArray(payload?.fields) && Array.isArray(payload?.data)){
    tables.push({fields:payload.fields,data:payload.data});
  }
  if(Array.isArray(payload?.tables)) tables.push(...payload.tables);
  for(const t of tables){
    const fields=(t?.fields||[]).map(x=>String(x).replace(/<[^>]+>/g,"").trim());
    const data=Array.isArray(t?.data)?t.data:[];
    for(const row of data){
      if(!Array.isArray(row))continue;
      const obj={}; fields.forEach((f,i)=>obj[f]=row[i]);
      const vals=row.map(x=>String(x??"").replace(/<[^>]+>/g,"").trim());
      if(vals.some(v=>v===String(code))) return {obj,fields,row};
    }
  }
  return null;
}
function pickField(obj,needles){
  for(const [k,v] of Object.entries(obj||{})){
    const kk=String(k).replace(/\s/g,"");
    if(needles.some(n=>kk.includes(n))) return v;
  }
  return null;
}
async function fetchTwseJson(url){
  const cache=caches.default;
  const key=new Request(`https://twse-cache.local/${encodeURIComponent(url)}`);
  const hit=await cache.match(key);
  if(hit){
    try{return await hit.json()}catch{}
  }
  const r=await fetch(url,{headers:{
    "accept":"application/json,text/plain,*/*",
    "user-agent":"Mozilla/5.0 (compatible; tw-stock-api/1.17.0)",
    "referer":"https://www.twse.com.tw/"
  }});
  if(!r.ok) throw new Error(`TWSE HTTP ${r.status}`);
  const text=await r.text();
  let j=null; try{j=JSON.parse(text)}catch{throw new Error("TWSE invalid JSON")}
  const resp=new Response(JSON.stringify(j),{status:200,headers:{
    "content-type":"application/json;charset=UTF-8",
    "cache-control":"public,max-age=21600"
  }});
  try{await cache.put(key,resp.clone())}catch{}
  return j;
}

async function marginForDate(code,iso){
  const date=twDateCompact(iso);
  try{
    const j=await fetchTwseJson(`https://www.twse.com.tw/rwd/zh/marginTrading/MI_MARGN?date=${date}&selectType=ALL&response=json`);
    const hit=rowByFields(j,code);
    if(!hit) return null;
    const o=hit.obj;
    const today=cleanNum(pickField(o,["今日餘額","今日融資餘額"]));
    const prev=cleanNum(pickField(o,["前日餘額","昨日餘額","昨日融資餘額"]));
    const buy=cleanNum(pickField(o,["融資買進"]));
    const sell=cleanNum(pickField(o,["融資賣出"]));
    if(today==null) return null;
    return {date:iso,stock_id:String(code),
      MarginPurchaseTodayBalance:today,
      MarginPurchaseYesterdayBalance:prev,
      MarginPurchaseBuy:buy,MarginPurchaseSell:sell};
  }catch(e){ return null; }
}

async function chipForDate(code,iso){
  const date=twDateCompact(iso);
  const result={date:iso,margin:null,inst:null,daytrade:null,errors:[]};

  // Margin balance
  try{
    const j=await fetchTwseJson(`https://www.twse.com.tw/rwd/zh/marginTrading/MI_MARGN?date=${date}&selectType=ALL&response=json`);
    const hit=rowByFields(j,code);
    if(hit){
      const o=hit.obj;
      const today=cleanNum(pickField(o,["今日餘額","今日融資餘額"]));
      const prev=cleanNum(pickField(o,["前日餘額","昨日餘額","昨日融資餘額"]));
      const buy=cleanNum(pickField(o,["融資買進"]));
      const sell=cleanNum(pickField(o,["融資賣出"]));
      if(today!=null) result.margin={
        date:iso,
        stock_id:String(code),
        MarginPurchaseTodayBalance:today,
        MarginPurchaseYesterdayBalance:prev,
        MarginPurchaseBuy:buy,
        MarginPurchaseSell:sell
      };
    }
  }catch(e){result.errors.push("margin:"+String(e.message||e))}

  // Institutional investors (official TWSE daily report backend)
  try{
    const j=await fetchTwseJson(`https://www.twse.com.tw/rwd/zh/fund/T86?date=${date}&selectType=ALL&response=json`);
    const hit=rowByFields(j,code);
    if(hit){
      const o=hit.obj;
      const foreign=cleanNum(pickField(o,["外陸資買賣超股數","外資及陸資買賣超股數","外資買賣超股數"]));
      const trust=cleanNum(pickField(o,["投信買賣超股數"]));
      const dealerSelf=cleanNum(pickField(o,["自營商買賣超股數(自行買賣)","自營商(自行買賣)買賣超股數"]));
      const dealerHedge=cleanNum(pickField(o,["自營商買賣超股數(避險)","自營商(避險)買賣超股數"]));
      const dealerTotal=(dealerSelf||0)+(dealerHedge||0);
      if(foreign!=null||trust!=null||dealerSelf!=null||dealerHedge!=null) result.inst={
        date:iso,stock_id:String(code),
        Foreign_Investor_buy:foreign>0?foreign:0,
        Foreign_Investor_sell:foreign<0?-foreign:0,
        Foreign_Dealer_Self_buy:0,
        Foreign_Dealer_Self_sell:0,
        Investment_Trust_buy:trust>0?trust:0,
        Investment_Trust_sell:trust<0?-trust:0,
        Dealer_buy:0,
        Dealer_sell:0,
        Dealer_self_buy:dealerSelf>0?dealerSelf:0,
        Dealer_self_sell:dealerSelf<0?-dealerSelf:0,
        Dealer_Hedging_buy:dealerHedge>0?dealerHedge:0,
        Dealer_Hedging_sell:dealerHedge<0?-dealerHedge:0
      };
    }
  }catch(e){result.errors.push("inst:"+String(e.message||e))}

  // Day trading — use the dated TWSE report only.
  // TWTB4U OpenAPI observed in audit is a suspension/status dataset, not day-trading volume.
  try{
    const j=await fetchTwseJson(`https://www.twse.com.tw/rwd/zh/dayTrading/TWTB4U?date=${date}&selectType=All&response=json`);
    const hit=rowByFields(j,code);
    if(hit){
      const vol=cleanNum(pickField(hit.obj,["當日沖銷交易成交股數","當日沖銷成交股數"]));
      if(vol!=null) result.daytrade={date:iso,stock_id:String(code),Volume:vol};
    }
  }catch(e){result.errors.push("daytrade:"+String(e.message||e))}
  return result;
}


const FUTURES_FALLBACK_CODES = [
  "1101","1102","1210","1216","1301","1303","1304","1305","1307","1308","1309","1312","1314","1319",
  "1402","1434","1476","1504","1513","1514","1519","1522","1536","1560","1590","1605","1707","1717","1722","1723",
  "1789","1795","1802","1904","2002","2014","2027","2049","2105","2201","2204","2206","2301","2303","2308","2312",
  "2313","2317","2324","2327","2330","2344","2345","2347","2352","2353","2354","2356","2357","2360","2368","2371",
  "2376","2377","2379","2382","2383","2385","2392","2404","2408","2409","2412","2421","2449","2454","2474","2492",
  "2498","2603","2609","2610","2615","2618","2634","2637","2707","2801","2880","2881","2882","2883","2884","2885",
  "2886","2887","2890","2891","2892","2912","3005","3017","3034","3035","3044","3059","3189","3231","3293","3374",
  "3443","3481","3532","3533","3653","3702","3711","4763","4904","4938","4958","5269","5347","5483","5871","5876",
  "5880","6176","6239","6257","6271","6285","6415","6446","6488","6505","6669","6770","6781","6805","8046","8069",
  "8150","8210","8299","8454","8464","9910","9921"
];

async function fetchTaifexStockFuturesCodes(){
  const urls=[
    "https://www.taifex.com.tw/cht/2/stockLists",
    "https://www.taifex.com.tw/cht/5/stockMarginingDetail",
    "https://www.taifex.com.tw/cht/2/sTF"
  ];
  const attempts=[];
  for(const u of urls){
    try{
      const r=await fetch(u,{
        headers:{
          "accept":"text/html,application/xhtml+xml",
          "user-agent":"Mozilla/5.0 (compatible; tw-stock-api/1.14.2)"
        }
      });
      const text=await r.text();
      attempts.push({url:u,status:r.status,bytes:text.length});
      if(!r.ok || text.length<1000) continue;

      const codes=new Set();
      // Official TAIFEX tables contain the underlying security code in a TD.
      // Restrict to four-digit ordinary-stock style values and exclude ETF 00xx.
      for(const m of text.matchAll(/<td[^>]*>\s*(\d{4})\s*<\/td>/gi)){
        const c=m[1];
        if(!c.startsWith("00")) codes.add(c);
      }
      // Some versions put table content inside spans/links; catch nearby 4-digit values too.
      if(codes.size<30){
        for(const m of text.matchAll(/(?:標的|證券|stock)[\s\S]{0,120}?(\d{4})/gi)){
          const c=m[1];
          if(!c.startsWith("00")) codes.add(c);
        }
      }
      if(codes.size>=30){
        return {ok:true,codes:[...codes].sort(),source:"TAIFEX official",attempts};
      }
    }catch(e){
      attempts.push({url:u,error:String(e?.message||e)});
    }
  }
  return {ok:true,codes:[...new Set(FUTURES_FALLBACK_CODES)].sort(),source:"embedded fallback",attempts};
}


/* ===== R17 Strategy Research Cache =====
   Isolated from Scanner/Detail/V4.4 production logic.
   The research lab NEVER calls FinMind during backtest runs. It reads this
   long-lived server-side cache only. Upstream/token usage happens only when
   the user explicitly presses "build missing cache".
*/
function researchCacheKey(origin,code,market){
  return new Request(`${origin}/__research-cache/v1/${String(market||"auto")}/${String(code)}`,{method:"GET"});
}
function mergeDateRows(a,b){
  const m=new Map();
  for(const r of [...(a||[]),...(b||[])]){
    const d=String(r?.date||"");
    if(d) m.set(d,r);
  }
  return [...m.values()].sort((x,y)=>String(x.date).localeCompare(String(y.date)));
}
async function readResearchCache(origin,code,market){
  try{
    const hit=await caches.default.match(researchCacheKey(origin,code,market));
    if(!hit) return null;
    const p=await hit.json();
    return p&&p.code?p:null;
  }catch{return null}
}
function researchCoverageOK(p,startDate,endDate){
  return Boolean(p && p.coverage_start && p.coverage_end && p.coverage_start<=startDate && p.coverage_end>=endDate);
}
async function writeResearchCache(origin,payload){
  const key=researchCacheKey(origin,payload.code,payload.market);
  const resp=new Response(JSON.stringify(payload),{headers:{
    "content-type":"application/json;charset=UTF-8",
    // Historical research data is deliberately long-lived. Cache API remains
    // best-effort, so the UI never claims this is a durable database.
    "cache-control":"public,max-age=31536000"
  }});
  await caches.default.put(key,resp);
}
async function callOwnApiJSON(path,request,env,origin){
  const headers=new Headers();
  const auth=request.headers.get("authorization");
  if(auth) headers.set("authorization",auth);
  const r=new Request(`${origin}${path}`,{method:"GET",headers});
  const resp=await routeApi(r,env,new URL(r.url));
  let body=null; try{body=await resp.clone().json()}catch{}
  return {ok:resp.ok&&body?.ok!==false,status:resp.status,body};
}

/* R19: dated, full-market snapshots. GET never fetches upstream. */
function r19Date(value) {
  const s=String(value||'').trim();
  let m=s.match(/^(\d{3,4})[-/](\d{1,2})[-/](\d{1,2})$/);
  if(!m && /^\d{8}$/.test(s)) m=[s,s.slice(0,4),s.slice(4,6),s.slice(6,8)];
  if(!m) return null;
  const y=Number(m[1])+(m[1].length===3?1911:0);
  const d=`${y}-${m[2].padStart(2,'0')}-${m[3].padStart(2,'0')}`;
  return Number.isFinite(Date.parse(d))&&new Date(d).toISOString().slice(0,10)===d?d:null;
}
function r19Snapshot(raw, market, date) {
  const returned=r19Date(raw.date||raw.reportDate||raw.queryDate);
  if(returned && returned!==date) throw new Error('Upstream returned a different date');
  const status=String(raw.stat||raw.status||raw.message||'');
  if(/沒有符合|查無資料|無交易資料|休市/.test(status)) return {date,market,rows:[],closed:true};
  if(!returned) throw new Error('Historical response has no verifiable date; refusing latest-day fallback');
  const tables=[...(raw.tables||[])];
  // Legacy TPEx full-market report: fixed published field order, dated report only.
  if(market==='tpex' && Array.isArray(raw.aaData) && returned===date){
    tables.push({fields:['代號','名稱','收盤','漲跌','開盤','最高','最低','均價','成交股數'],data:raw.aaData});
  }
  if(raw.fields) tables.push({fields:raw.fields,data:raw.data});
  for(const k of Object.keys(raw)) if(/^fields\d+$/.test(k)) tables.push({fields:raw[k],data:raw[k.replace('fields','data')]});
  const clean=s=>String(s).replace(/<[^>]*>/g,'').replace(/\s/g,'');
  const number=s=>{const t=clean(s??'').replace(/,/g,'');return t && !/--|除權|除息/.test(t)&&Number.isFinite(Number(t))?Number(t):null};
  for(const t of tables){
    const fields=(t.fields||[]).map(x=>clean(typeof x==='object'?(x.title||x.name||''):x));
    const index=re=>fields.findIndex(f=>re.test(f));
    const ix={code:index(/^(證券代號|代號|股票代號)$/),name:index(/^(證券名稱|名稱|股票名稱)$/),open:index(/^開盤(價)?$/),high:index(/^最高(價)?$/),low:index(/^最低(價)?$/),close:index(/^收盤(價)?$/),volume:index(/^成交(股數|仟股|千股|張數)(\(.*\))?$/)};
    if(Object.values(ix).some(i=>i<0)||!Array.isArray(t.data))continue;
    const declared=Number(t.totalCount??raw.iTotalRecords);
    if(Number.isFinite(declared)&&declared>t.data.length)throw new Error('Paginated market report is incomplete');
    const factor=/仟股|千股|張數/.test(fields[ix.volume])?1000:1;
    if(t.data.length===0 && /^(ok|200)$/i.test(status)) return {date,market,rows:[],closed:true};
    const rows=t.data.filter(Array.isArray).map(r=>({date,market,code:clean(r[ix.code]),name:clean(r[ix.name]),open:number(r[ix.open]),high:number(r[ix.high]),low:number(r[ix.low]),close:number(r[ix.close]),volume:number(r[ix.volume])===null?null:number(r[ix.volume])*factor})).filter(r=>/^[1-9]\d{3}$/.test(r.code));
    if(rows.length<100||rows.some(r=>r.volume===null||r.volume<0))throw new Error('Incomplete full-market table or invalid volume');
    if(new Set(rows.map(r=>r.code)).size!==rows.length)throw new Error('Duplicate stock in market snapshot');
    return {date,market,rows,closed:false};
  }
  throw new Error('Unrecognized historical OHLC/volume table; no snapshot published');
}
/* R19.1: independent, explicitly selected FinMind data service. */
function r191Failure(code,message){const e=new Error(message);e.code=code;return e;}
function r191Blocked(e){return /安全性考量|FOR SECURITY REASONS|PAGE CAN ?NOT BE ACCESSED|access denied/i.test(String(e?.message||e));}
async function r191FinMindDS(dataset,date,token){
  const q=new URLSearchParams({dataset});if(date)q.set('start_date',date);
  let response,raw;
  try{
    response=await fetch(`https://api.finmindtrade.com/api/v4/data?${q}`,{headers:{Authorization:`Bearer ${token}`,accept:'application/json'},signal:AbortSignal.timeout(30000)});
    raw=await response.json();
  }catch(e){throw r191Failure('PROVIDER_UNAVAILABLE','FinMind 目前無法取得資料，未寫入成功快取。');}
  if(response.status===429||Number(raw.status)===402||Number(raw.status)===429)throw r191Failure('PROVIDER_QUOTA','FinMind 配額或方案限制；請確認帳戶額度，稍後再補齊。');
  if(!response.ok||Number(raw.status)!==200||!Array.isArray(raw.data))throw r191Failure('PROVIDER_ACCESS','FinMind 未授權此請求。全市場 TaiwanStockPrice 需要 backer／sponsor 權限；一般 Token 不保證可用。');
  return raw.data;
}
async function r191Metadata(origin,token,dataset){
  const k=new Request(`${origin}/__research-provider/r191/${dataset}`),hit=await caches.default.match(k);
  if(hit)return (await hit.json()).data;
  const data=await r191FinMindDS(dataset,null,token);
  if(!data.length)throw r191Failure('PROVIDER_DATA','FinMind 市場分類或交易日資料為空。');
  await caches.default.put(k,new Response(JSON.stringify({data}),{headers:{'content-type':'application/json','cache-control':'public,max-age=86400'}}));return data;
}
function r191Classify(info,date){
  // Provider documents that a former market row's date stops at departure.
  // Infer intervals from those end dates; never use today's latest type for all history.
  const rows=info.filter(r=>['twse','tpex','emerging'].includes(r.type)&&r19Date(r.date)===r.date).sort((a,b)=>a.date.localeCompare(b.date));
  const picked=rows.find(r=>r.date>=date);if(!picked)return null;
  if(new Set(rows.filter(r=>r.date===picked.date).map(r=>r.type)).size!==1)return null;
  return picked;
}
function r191NormalizeFinMind(raw,info,date){
  const map=new Map();for(const r of info){const code=String(r.stock_id);if(!map.has(code))map.set(code,[]);map.get(code).push(r);}
  const out={twse:[],tpex:[]},unknown=[],seen=new Set();
  const number=v=>v===null||v===undefined||v===''?null:(Number.isFinite(Number(v))?Number(v):null);
  for(const r of raw){
    if(r.date!==date)throw r191Failure('PROVIDER_DATE','FinMind 回傳日期不符，拒絕將最新資料用於歷史排名。');
    const code=String(r.stock_id);if(!/^[1-9]\d{3}$/.test(code))continue;
    if(seen.has(code))throw r191Failure('PROVIDER_DATA','FinMind 同日股票代號重複。');seen.add(code);
    const meta=r191Classify(map.get(code)||[],date);if(!meta){unknown.push(code);continue;}
    if(meta.type==='emerging')continue;
    const volume=number(r.Trading_Volume);if(volume===null||volume<0)throw r191Failure('PROVIDER_DATA','FinMind 成交股數缺漏，不能排名。');
    out[meta.type].push({date,market:meta.type,code,name:String(meta.stock_name||code),open:number(r.open),high:number(r.max),low:number(r.min),close:number(r.close),volume});
  }
  if(unknown.length)throw r191Failure('MARKET_MAPPING',`無法確定 ${unknown.length} 檔歷史市場別（${unknown.slice(0,5).join('、')}）。未排除後硬算前百名；請改用帶市場別的歷史資料匯入。`);
  if(out.twse.length<100||out.tpex.length<100)throw r191Failure('PROVIDER_DATA','FinMind 回傳市場資料不足，未發布部分市場快取。');
  return out;
}
async function r191FinMindDay(request,env,url,date){
  const token=await requestFinMindToken(request,env,url.origin);
  if(!token)throw r191Failure('TOKEN_REQUIRED','請先在原掃描器設定 FinMind Token；全市場日資料另需 backer／sponsor 權限。');
  const raw=await r191FinMindDS('TaiwanStockPrice',date,token);
  let rows;
  if(!raw.length){
    const calendar=await r191Metadata(url.origin,token,'TaiwanStockTradingDate');const dates=calendar.map(x=>x.date).filter(d=>r19Date(d)===d).sort();
    if(!dates.length||date<=dates[0]||date>=dates.at(-1)||dates.includes(date))throw r191Failure('PROVIDER_EMPTY','當日全市場資料為空，且無法確認休市。請等待資料完整後再試。');
    rows={twse:[],tpex:[]};
  }else rows=r191NormalizeFinMind(raw,await r191Metadata(url.origin,token,'TaiwanStockInfo'),date);
  const result={};
  for(const market of ['twse','tpex']){
    const payload={ok:true,version:19,patch:'19.1',date,market,rows:rows[market],closed:!raw.length,source:'FinMind TaiwanStockPrice',provider:'finmind',market_mapping:'provider-end-date-inference',cached_at:new Date().toISOString(),token_used:true};
    result[market]=payload;
  }
  // Validate both markets before publishing either; cached second market saves another bulk call.
  for(const market of ['twse','tpex'])await caches.default.put(new Request(`${url.origin}/__research-market/r191/finmind/${market}/${date}`),new Response(JSON.stringify(result[market]),{headers:{'content-type':'application/json','cache-control':'public,max-age=31536000'}}));
  return result;
}

async function r19MarketRoute(request,url,env={}) {
  const date=url.searchParams.get('date'),market=url.searchParams.get('market');
  const todayTW=new Date(Date.now()+8*3600000).toISOString().slice(0,10);
  if(typeof date!=='string'||r19Date(date)!==date||!['twse','tpex'].includes(market)||date>=''+todayTW||date<'2010-01-01')return json({ok:false,error:'Valid historical date (before Taiwan today) and market required'},400);
  if(!['GET','POST'].includes(request.method))return json({ok:false,error:'GET to load, POST to build'},405);
  const provider=url.searchParams.get('source')||'official';
  if(!['official','finmind'].includes(provider))return json({ok:false,error:'Unknown source'},400);
  const key=new Request(provider==='official'?`${url.origin}/__research-market/r19/${market}/${date}`:`${url.origin}/__research-market/r191/finmind/${market}/${date}`);
  const hit=await caches.default.match(key);
  if(hit) return json({...await hit.json(),cache_hit:true,upstream_used:false});
  if(request.method==='GET')return json({ok:false,cache_only:true,error:'Market snapshot missing; explicitly build first'},404);
  if(provider==='finmind'){
    try{return json({...((await r191FinMindDay(request,env,url,date))[market]),cache_hit:false,upstream_used:true});}
    catch(e){return json({ok:false,code:e.code||'PROVIDER_ERROR',error:e.message||'FinMind 資料建置失敗',market,date,source:'finmind',cache_preserved:true},502);}
  }
  const blockKey=new Request(`${url.origin}/__research-source-block/r191/${market}`);
  const blocked=await caches.default.match(blockKey);
  if(blocked)return json({...await blocked.json(),date,retry_after:600},503,{'retry-after':'600'});
  const roc=`${Number(date.slice(0,4))-1911}/${date.slice(5,7)}/${date.slice(8,10)}`;
  const urls=market==='twse'
    ? [`https://www.twse.com.tw/exchangeReport/MI_INDEX?response=json&date=${date.replace(/-/g,'')}&type=ALLBUT0999`]
    : [`https://www.tpex.org.tw/www/zh-tw/afterTrading/dailyQuotes?date=${date.replace(/-/g,'/')}&id=&response=json`,
       `https://www.tpex.org.tw/web/stock/aftertrading/daily_close_quotes/stk_quote_result.php?l=zh-tw&d=${roc}&o=json&se=EW`];
  const errors=[];
  for(const upstream of urls){
    try{
      const raw=await fetchJson(upstream,{signal:AbortSignal.timeout(15000)});
      const snapshot=r19Snapshot(raw,market,date);
      const payload={ok:true,version:19,...snapshot,source:upstream,cached_at:new Date().toISOString(),token_used:false};
      await caches.default.put(key,new Response(JSON.stringify(payload),{headers:{'content-type':'application/json','cache-control':'public,max-age=31536000'}}));
      return json({...payload,cache_hit:false,upstream_used:true});
    }catch(e){
      if(r191Blocked(e)){
        const failure={ok:false,code:'SOURCE_BLOCKED',market,date,source:'official',cache_preserved:true,error:`${market.toUpperCase()} 拒絕伺服器存取歷史行情，並回傳安全性阻擋頁。已停止重試；可選擇有權限的 FinMind 全市場來源，或匯入完整歷史行情 JSON。`};
        await caches.default.put(blockKey,new Response(JSON.stringify(failure),{headers:{'content-type':'application/json','cache-control':'public,max-age=600'}}));
        return json(failure,503,{'retry-after':'600'});
      }
      errors.push(/timeout|abort/i.test(String(e.message))?'來源逾時':'來源回應錯誤或格式無法驗證');
    }
  }
  return json({ok:false,code:'SOURCE_UNAVAILABLE',error:`${market.toUpperCase()} ${date}：${errors.join(' / ')}。未寫入成功快取，可改選 FinMind 或匯入歷史行情。`,date,market,cache_preserved:true},502);
}

// R19.3 fixed-universe history: explicit provider, cache-only reads, no paid bulk API.
function r193Bars(raw,code,start,end){
  const seen=new Set();
  const data=raw.map(r=>{
    if(String(r.stock_id)!==code||r19Date(r.date)!==r.date||r.date<start||r.date>end||seen.has(r.date))throw Error('個股代碼、日期範圍或重複資料驗證失敗');
    seen.add(r.date);
    const b={date:r.date,open:r.open,high:r.max,low:r.min,close:r.close,volume:r.Trading_Volume};
    if(!Object.values(b).slice(1).every(v=>typeof v==='number'&&Number.isFinite(v))||b.volume<0||b.low<0||b.high<Math.max(b.open,b.close,b.low)||b.low>Math.min(b.open,b.close))throw Error(r.date+' 個股 OHLC／成交量驗證失敗：'+JSON.stringify(b));
    return b;
  }).sort((a,b)=>a.date.localeCompare(b.date));
  if(!data.length)throw Error('這個期間沒有個股行情；未快取為成功');
  return data;
}
async function r193History(request,env,url){
  const code=url.searchParams.get('code'),market=url.searchParams.get('market'),start=url.searchParams.get('start_date'),end=url.searchParams.get('end_date'),provider=url.searchParams.get('source')||'auto';
  // Five signal years plus the UI's 180-day indicator warm-up allowance.
  if(!/^\d{4}$/.test(code||'')||!['twse','tpex'].includes(market)||!start||!end||r19Date(start)!==start||r19Date(end)!==end||start>=end||end>=isoDateTaipei()||(Date.parse(end)-Date.parse(start))/86400000>2010||!['auto','finmind'].includes(provider))return json({ok:false,error:'無效個股、歷史期間或來源（最多 5 年訊號期＋180 日暖機）'},400);
  if(!['GET','POST'].includes(request.method))return json({ok:false,error:'GET 查快取，POST 補齊'},405);
  const key=new Request(`${url.origin}/__research-history/r193/${provider}/${market}/${code}/${start}/${end}`);
  const cached=await caches.default.match(key);if(cached)return json({...await cached.json(),cache_hit:true});
  if(request.method==='GET')return json({ok:false,error:'個股行情快取尚未建立'},404);
  const label=`${market}:${code}（${start} ～ ${end}）`;
  let payload;
  try{
    if(provider==='finmind'){
      const token=await requestFinMindToken(request,env,url.origin);
      if(!token)return json({ok:false,error:label+'：請先在掃描器設定 FinMind Token；此處使用個股歷史 API。'},401);
      const q=new URLSearchParams({dataset:'TaiwanStockPrice',data_id:code,start_date:start,end_date:end});
      const r=await fetch('https://api.finmindtrade.com/api/v4/data?'+q,{headers:{Authorization:'Bearer '+token,accept:'application/json'},signal:AbortSignal.timeout(30000)});
      let j;try{j=await r.json();}catch{throw Error('FinMind 回應不是 JSON，請稍後續接');}
      if(r.status===429||[402,429].includes(Number(j.status)))return json({ok:false,error:label+'：FinMind 配額／方案限制，已停止；保留已完成資料，稍後再補齊。'},429);
      if(!r.ok||Number(j.status)!==200||!Array.isArray(j.data))throw Error('FinMind 無法提供個股資料（狀態 '+r.status+'）；請確認 Token／帳戶權限');
      payload={ok:true,data:r193Bars(j.data,code,start,end),source:'FinMind TaiwanStockPrice individual',token_used:true};
    }else{
      const u=new URL(url.origin+'/api/history/auto');for(const [k,v] of Object.entries({code,market,start_date:start,end_date:end}))u.searchParams.set(k,v);
      const r=await routeApi(new Request(u),env,u);const j=await r.json();
      if(!r.ok||!j.ok){
        const statuses=[...new Set((j.yahoo_attempts||[]).map(a=>a.status?'HTTP '+a.status:'連線／解析失敗'))].join('、');
        throw Error('Yahoo '+(statuses||'資料不足或來源失敗')+(market==='tpex'?'；目前沒有上櫃官方個股歷史備援':'；上市官方備援也未成功')+'。可改選「FinMind 個股行情」再補齊；不需全市場查詢權限');
      }
      payload={...j,token_used:false};
    }
    payload={...payload,code,market,start_date:start,end_date:end,provider,cached_at:new Date().toISOString()};
    await caches.default.put(key,new Response(JSON.stringify(payload),{headers:{'content-type':'application/json','cache-control':'public,max-age=31536000'}}));
    return json(payload);
  }catch(e){return json({ok:false,error:label+'：'+(/timeout|abort|fetch failed/i.test(e.message)?'來源逾時或連線失敗，已保留完成快取，請稍後續接':e.message),code,market,provider},502);}
}

// Independent research chip pieces; never downloads price history.
const r196Datasets={margin:'TaiwanStockMarginPurchaseShortSale',inst:'TaiwanStockInstitutionalInvestorsBuySellWide',daytrade:'TaiwanStockDayTrading'};
function r196Validate(rows,kind,code,start,end){
  const seen=new Set(),num=v=>typeof v==='number'&&Number.isFinite(v);
  for(const r of rows){
    if(String(r.stock_id)!==code||r19Date(r.date)!==r.date||r.date<start||r.date>end||seen.has(r.date))throw Error('資料代碼／日期驗證失敗');
    seen.add(r.date);
    const keys=kind==='margin'?['MarginPurchaseTodayBalance','MarginPurchaseYesterdayBalance']:kind==='daytrade'?['Volume']:['Foreign_Investor_buy','Foreign_Investor_sell','Investment_Trust_buy','Investment_Trust_sell'];
    if(keys.some(k=>!num(r[k])||r[k]<0))throw Error('欄位缺漏或格式錯誤，不補零');
  }
  return rows.sort((a,b)=>a.date.localeCompare(b.date));
}
async function r196ChipRoute(request,env,url){
  const code=url.searchParams.get('code'),market=url.searchParams.get('market'),start=url.searchParams.get('start_date'),end=url.searchParams.get('end_date'),kind=url.searchParams.get('kind');
  if(!r196Datasets[kind]||!/^\d{4}$/.test(code||'')||!['twse','tpex'].includes(market)||!start||!end||r19Date(start)!==start||r19Date(end)!==end||start>=end||end>=isoDateTaipei()||(Date.parse(end)-Date.parse(start))/86400000>2010)return json({ok:false,error:'無效籌碼參數（最多 5 年訊號期＋180 日暖機）'},400);
  if(!['GET','POST'].includes(request.method))return json({ok:false,error:'GET 查快取，POST 補齊'},405);
  const key=new Request(`${url.origin}/__research-chip/r196/${kind}/${market}/${code}/${start}/${end}`),cache=caches.default,hit=await cache.match(key);
  if(hit)return json({...await hit.json(),cache_hit:true});
  if(request.method==='GET')return json({ok:false,error:'尚未下載',reason:'not_downloaded'},404);
  const token=await requestFinMindToken(request,env,url.origin);
  if(!token)return json({ok:false,error:'請設定 FinMind Token',reason:'auth'},401);
  try{
    const q=new URLSearchParams({dataset:r196Datasets[kind],data_id:code,start_date:start,end_date:end});
    const response=await fetch('https://api.finmindtrade.com/api/v4/data?'+q,{headers:{Authorization:'Bearer '+token,accept:'application/json'},signal:AbortSignal.timeout(30000)});
    let j;try{j=await response.json();}catch{return json({ok:false,error:'來源未回傳 JSON',reason:'source_error'},502);}
    if(response.status===429||[402,429].includes(Number(j.status)))return json({ok:false,error:'FinMind 配額／方案限制；已完成的各類籌碼可續接',reason:'quota'},429);
    if([401,403].includes(response.status)||[401,403].includes(Number(j.status)))return json({ok:false,error:'FinMind Token 或資料集權限不足',reason:'auth'},403);
    if(!response.ok||Number(j.status)!==200||!Array.isArray(j.data))return json({ok:false,error:'FinMind 資料集請求失敗',reason:'source_error'},502);
    const data=r196Validate(j.data,kind,code,start,end),payload={ok:true,data,kind,code,market,coverage_start:start,coverage_end:end,source:r196Datasets[kind],state:data.length?'received':'no_data',cached_at:new Date().toISOString()};
    await cache.put(key,new Response(JSON.stringify(payload),{headers:{'content-type':'application/json','cache-control':'public,max-age='+ (data.length?31536000:3600)}}));
    return json(payload);
  }catch(e){return json({ok:false,error:/欄位|驗證/.test(e.message)?e.message:'來源連線失敗或逾時',reason:/欄位|驗證/.test(e.message)?'invalid_data':'source_error'},502);}
}

// TAIEX price index benchmark: Yahoo with dated TWSE monthly fallback. No FinMind calls.
function r1910Normalize(rows,start,end){
 const seen=new Set();const data=rows.filter(r=>r.date>=start&&r.date<=end);
 if(!data.length)throw Error('大盤來源沒有指定期間資料');
 for(const r of data){if(r19Date(r.date)!==r.date||seen.has(r.date)||!Number.isFinite(r.close)||r.close<=0)throw Error('大盤日期或收盤值驗證失敗');seen.add(r.date);}
 return data.sort((a,b)=>a.date.localeCompare(b.date));
}
async function r1910BenchmarkRoute(request,url){
 const start=url.searchParams.get('start_date'),end=url.searchParams.get('end_date');
 if(!start||!end||r19Date(start)!==start||r19Date(end)!==end||start>=end||end>=isoDateTaipei()||(Date.parse(end)-Date.parse(start))/86400000>2010)return json({ok:false,error:'大盤歷史期間無效'},400);
 if(!['GET','POST'].includes(request.method))return json({ok:false,error:'GET查快取，POST補齊'},405);
 const key=new Request(`${url.origin}/__research-benchmark/r1910/${start}/${end}`),hit=await caches.default.match(key);if(hit)return hit;
 if(request.method==='GET')return json({ok:false,error:'大盤尚未下載'},404);
 const p1=unixSec(start),p2=unixSec(addDaysISO(end,1));let data,source;
 for(const host of ['query1.finance.yahoo.com','query2.finance.yahoo.com']){
  try{const r=await fetch(`https://${host}/v8/finance/chart/%5ETWII?period1=${p1}&period2=${p2}&interval=1d`,{headers:{accept:'application/json'},signal:AbortSignal.timeout(10000)});if(!r.ok)continue;const j=await r.json(),v=j.chart?.result?.[0];if(v?.meta?.symbol!=='^TWII')continue;
   data=r1910Normalize((v.timestamp||[]).map((t,i)=>({date:new Date(t*1000).toISOString().slice(0,10),close:v.indicators?.quote?.[0]?.close?.[i]})).filter(r=>Number.isFinite(r.close)&&r.close>0),start,end);source='Yahoo ^TWII';break;
  }catch{}
 }
 if(!data){
  const rows=[];let month=start.slice(0,7)+'-01';
  try{while(month<=end){
   const r=await fetch('https://www.twse.com.tw/exchangeReport/FMTQIK?response=json&date='+month.replaceAll('-',''),{headers:{accept:'application/json'},signal:AbortSignal.timeout(10000)});if(!r.ok)throw Error('來源不可用');const j=await r.json();
   if(r19Date(j.date)?.slice(0,7)!==month.slice(0,7)||!Array.isArray(j.fields)||!Array.isArray(j.data))throw Error('月份無法驗證');
   const idx=j.fields.findIndex(f=>String(f).replace(/\s/g,'')==='發行量加權股價指數');if(idx<0)throw Error('指數欄位無法辨識');
   for(const row of j.data){const date=r19Date(row[0]);if(!date||date.slice(0,7)!==month.slice(0,7))throw Error('日期無法驗證');rows.push({date,close:Number(String(row[idx]).replaceAll(',',''))});}
   const d=new Date(month+'T00:00:00Z');d.setUTCMonth(d.getUTCMonth()+1);month=d.toISOString().slice(0,10);
  }data=r1910Normalize(rows,start,end);source='TWSE FMTQIK';}catch{return json({ok:false,error:'大盤來源無法取得或驗證歷史資料；策略結果保留，稍後可只補大盤，不會使用FinMind配額'},502);}
 }
 const response=json({ok:true,data,source,symbol:'TAIEX',returnType:'price',start_date:start,end_date:end,cached_at:new Date().toISOString()},200,{'cache-control':'public,max-age=31536000'});await caches.default.put(key,response.clone());return response;
}

async function routeApi(request, env, url) {
  if(url.pathname === "/api/research/benchmark")return r1910BenchmarkRoute(request,url);
  if(url.pathname === "/api/research/chip-piece") return r196ChipRoute(request,env,url);
  if(url.pathname === "/api/research/stock-history") return r193History(request,env,url);
  if(url.pathname === "/api/research/market-day") return r19MarketRoute(request,url,env);
  // R12 bug fix: EFFECTIVE_FINMIND_TOKEN must exist in THIS scope.
  // R12 created it in export.fetch(), but routeApi() referenced it directly,
  // causing ReferenceError on /api/finmind/status and all FinMind-assisted routes.
  const EFFECTIVE_FINMIND_TOKEN=await requestFinMindToken(request,env,url.origin);
  if (request.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS });
  }

  if (url.pathname === "/api/health") {
    return json({
      ok: true,
      service: "tw-stock-api",
      version: "1.17.0-R21",
      time_utc: new Date().toISOString(),
      finmind_secret_configured: Boolean(env.FINMIND_TOKEN),
    });
  }


  if (url.pathname === "/api/futures/stock-list") {
    const cacheKey=new Request(`${url.origin}/__cache/taifex-stock-futures`);
    const cache=caches.default;
    const cached=await cache.match(cacheKey);
    if(cached) return cached;

    const r=await fetchTaifexStockFuturesCodes();
    const resp=json({
      ok:r.ok,
      source:r.source,
      count:r.codes.length,
      codes:r.codes,
      attempts:r.attempts
    },200,{"cache-control":"public,max-age=21600"});
    await cache.put(cacheKey,resp.clone());
    return resp;
  }

  if (url.pathname === "/api/twse/all") {
    const upstream = "https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL";
    try {
      const raw = await fetchJson(upstream);
      const data = normalizeTwse(raw);
      return json({
        ok: true,
        source: "TWSE OpenAPI",
        upstream,
        count: data.length,
        ordinary_count: data.filter(ordinaryStock).length,
        data,
      });
    } catch (e) {
      return json({ ok: false, source: "TWSE OpenAPI", upstream, error: String(e.message || e) }, 502);
    }
  }

  if (url.pathname === "/api/tpex/debug") {
    const result = await fetchTpexAll();
    return json({
      ok:result.ok,
      mode:result.mode||null,
      upstream:result.upstream||null,
      attempts:result.attempts||[],
      sample:Array.isArray(result.raw)?result.raw.slice(0,5):[],
      payload_meta:result.payload_meta||null
    }, result.ok?200:502);
  }

  if (url.pathname === "/api/tpex/all") {
    const result = await fetchTpexAll();
    if (!result.ok) {
      return json({
        ok:false,
        source:"TPEx OpenAPI",
        error:"All official TPEx OpenAPI candidates failed or redirected.",
        attempts:result.attempts
      }, 502);
    }
    const data=normalizeTpex(result.raw);
    return json({
      ok:true,
      source:"TPEx OpenAPI",
      upstream:result.upstream,
      count:data.length,
      ordinary_count:data.filter(ordinaryStock).length,
      attempts:result.attempts,
      data
    });
  }


  if (url.pathname === "/api/market/universe") {
    const [twseRaw,tpex]=await Promise.all([
      fetchJson("https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL")
        .then(raw=>({ok:true,data:normalizeTwse(raw).filter(ordinaryStock)}))
        .catch(e=>({ok:false,data:[],error:String(e?.message||e)})),
      fetchTpexUniverse()
    ]);
    // STOCK_DAY_ALL is used only for universe/current prefilter fields.
    // Never attach an inferred trading date to it.
    const twse=twseRaw.data.map(x=>({
      market:"twse",code:x.code,name:x.name,
      close:roundTwPrice(x.close),open:roundTwPrice(x.open),high:roundTwPrice(x.high),low:roundTwPrice(x.low),
      volume_shares:x.volume_shares,turnover:x.turnover
    }));
    const merged=new Map();
    // Add TPEx first, then overwrite by TWSE. Taiwan ordinary-stock codes are unique;
    // if the OTC parser accidentally captures a listed code, TWSE must win.
    for(const x of tpex.data) if(/^\d{4}$/.test(String(x.code||""))) merged.set(String(x.code),x);
    for(const x of twse) merged.set(String(x.code),x);
    const universe=[...merged.values()];
    const tpexClean=universe.filter(x=>x.market==="tpex").length;
    const twseClean=universe.filter(x=>x.market==="twse").length;
    return json({ok:twseRaw.ok||tpex.ok,data:universe,
      counts:{twse:twseClean,tpex:tpexClean,total:universe.length},
      sources:{
        twse:{ok:twseRaw.ok,error:twseRaw.error||null},
        tpex:{ok:tpex.ok,source:tpex.source,upstream:tpex.upstream||null,error:tpex.error||null,attempts:tpex.attempts||[]}
      }
    },(twseRaw.ok||tpex.ok)?200:502,{"cache-control":"no-store"});
  }

  if (url.pathname === "/api/market/filter") {
    const minClose=Number(url.searchParams.get("min_close")||10);
    const minLots=Number(url.searchParams.get("min_lots")||3000);
    const minShares=minLots*1000;

    const twsePromise=fetchJson("https://openapi.twse.com.tw/v1/exchangeReport/STOCK_DAY_ALL")
      .then(raw=>({ok:true,data:normalizeTwse(raw)}))
      .catch(e=>({ok:false,data:[],error:String(e?.message||e)}));
    const tpexPromise=fetchTpexAll()
      .then(r=>r.ok?({ok:true,data:normalizeTpex(r.raw),upstream:r.upstream,attempts:r.attempts})
                    :({ok:false,data:[],error:"TPEx unavailable",attempts:r.attempts}));

    const [twse,tpex]=await Promise.all([twsePromise,tpexPromise]);
    const all=[...twse.data,...tpex.data];
    const filtered=all.filter(x=>
      ordinaryStock(x) &&
      Number.isFinite(x.close) && x.close>=minClose &&
      Number.isFinite(x.volume_shares) && x.volume_shares>=minShares
    ).sort((a,b)=>b.volume_shares-a.volume_shares);

    return json({
      ok:twse.ok || tpex.ok,
      partial:!(twse.ok && tpex.ok),
      filters:{min_close:minClose,min_lots:minLots},
      sources:{
        twse:{ok:twse.ok,count:twse.data.length,error:twse.error||null},
        tpex:{ok:tpex.ok,count:tpex.data.length,error:tpex.error||null,upstream:tpex.upstream||null,attempts:tpex.attempts||[]}
      },
      total_raw:all.length,
      count:filtered.length,
      data:filtered
    }, (twse.ok||tpex.ok)?200:502);
  }


  if (url.pathname === "/api/history/yahoo") {
    const code=url.searchParams.get("code")||"3443";
    const market=url.searchParams.get("market")||"";
    const endDate=url.searchParams.get("end_date")||isoDateTaipei();
    const startDate=url.searchParams.get("start_date")||addDaysISO(endDate,-460);
    const r=await fetchYahooHistory(code,market,startDate,endDate);
    return json({...r,count:r.data.length,first:r.data[0]?.date||null,last:r.data.at(-1)?.date||null},r.ok?200:502);
  }

  if (url.pathname === "/api/history/twse") {
    const code=url.searchParams.get("code")||"3443";
    const endDate=url.searchParams.get("end_date")||isoDateTaipei();
    const startDate=url.searchParams.get("start_date")||addDaysISO(endDate,-460);
    const r=await fetchTwseMonthlyHistory(code,startDate,endDate);
    return json({...r,count:r.data.length,first:r.data[0]?.date||null,last:r.data.at(-1)?.date||null},r.ok?200:502);
  }


  if (url.pathname === "/api/intraday") {
    const code=url.searchParams.get("code")||"2330";
    const market=url.searchParams.get("market")||"";
    if(!/^\d{4}$/.test(String(code)))return json({ok:false,error:'invalid stock code'},400);
    const suffixes=market==="tpex"?[".TWO",".TW"]:market==="twse"?[".TW",".TWO"]:[".TW",".TWO"];
    const attempts=[];
    let officialTried=false;
    const pos=v=>{
      if(v===null||v===undefined||v==='')return null;
      const n=Number(v);
      return Number.isFinite(n)&&n>0?n:null;
    };
    const vol=v=>{
      if(v===null||v===undefined||v==='')return 0;
      const n=Number(v);
      return Number.isFinite(n)&&n>=0?n:0;
    };
    for(const suffix of suffixes){
      const symbol=String(code)+suffix;
      const hosts=["query1.finance.yahoo.com","query2.finance.yahoo.com"];
      for(let hostIndex=0;hostIndex<hosts.length;hostIndex++){
        if(hostIndex>0&&!officialTried){
          officialTried=true;
          const official=await fetchTwseMisIntraday(code,market,attempts);
          if(official)return json(official,200,{"cache-control":"no-store"});
        }
        const host=hosts[hostIndex];
        try{
          const u=`https://${host}/v8/finance/chart/${encodeURIComponent(symbol)}?range=1d&interval=1m&includePrePost=false`;
          const r=await fetch(u,{headers:{"accept":"application/json,text/plain,*/*","user-agent":"Mozilla/5.0 Chrome/131"},signal:AbortSignal.timeout(5000)});
          attempts.push({host,symbol,status:r.status});
          if(!r.ok) continue;
          const j=await r.json(),z=j?.chart?.result?.[0],ts=z?.timestamp||[],q=z?.indicators?.quote?.[0]||{};
          if(!ts.length) continue;
          const day=t=>new Intl.DateTimeFormat("sv-SE",{timeZone:"Asia/Taipei",year:"numeric",month:"2-digit",day:"2-digit"}).format(new Date(t*1000));
          const time=t=>new Intl.DateTimeFormat("zh-TW",{timeZone:"Asia/Taipei",hour:"2-digit",minute:"2-digit",second:"2-digit",hour12:false}).format(new Date(t*1000));
          const latestDay=day(ts.at(-1)),rows=[];
          for(let i=0;i<ts.length;i++){
            if(day(ts[i])!==latestDay) continue;
            const close=pos(q.close?.[i]);
            if(close===null) continue;
            rows.push({t:ts[i],open:pos(q.open?.[i]),high:pos(q.high?.[i]),low:pos(q.low?.[i]),close,volume:vol(q.volume?.[i])});
          }
          if(!rows.length) continue;
          const opens=rows.map(x=>x.open).filter(v=>v!==null),highs=rows.map(x=>x.high).filter(v=>v!==null),lows=rows.map(x=>x.low).filter(v=>v!==null),closes=rows.map(x=>x.close).filter(v=>v!==null);
          const last=rows.at(-1),meta=z?.meta||{},prev=pos(meta.chartPreviousClose??meta.previousClose);
          const openRaw=opens[0]??closes[0]??null,closeRaw=last.close;
          const highPool=[...highs,openRaw,closeRaw].filter(v=>v!==null),lowPool=[...lows,openRaw,closeRaw].filter(v=>v!==null);
          const highRaw=highPool.length?Math.max(...highPool):null,lowRaw=lowPool.length?Math.min(...lowPool):null;
          const open=openRaw===null?null:roundTwPrice(openRaw),high=highRaw===null?null:roundTwPrice(highRaw),low=lowRaw===null?null:roundTwPrice(lowRaw),close=roundTwPrice(closeRaw),prevClose=prev===null?null:roundTwPrice(prev);
          const bar={date:latestDay,open,high,low,close,volume:rows.reduce((s,x)=>s+x.volume,0),last_time:time(last.t),last_timestamp:last.t,prev_close:prevClose,change:Number.isFinite(prevClose)?roundTwPrice(close-prevClose):null,change_pct:Number.isFinite(prevClose)&&prevClose!==0?(close-prevClose)/prevClose*100:null,symbol};
          const validation_errors=intradayValidationErrors(bar);
          const session=taipeiSessionState();
          const quote={
            ok:true,quote_valid:validation_errors.length===0,validation_errors,
            source:'Yahoo Finance 1m intraday',symbol,bar,points:rows.length,attempts,
            market_state:meta.marketState||null,
            session_open:session.is_open && latestDay===session.date,
            session_date:session.date
          };
          if(!validation_errors.length)return json(quote,200,{"cache-control":"no-store"});
          attempts.push({host,symbol,error:'quote validation failed',validation_errors});
        }catch(e){attempts.push({host,symbol,error:String(e?.message||e)})}
        // Yahoo is intermittently rate-limited around the Taiwan open. Try the
        // exchange realtime service after the first Yahoo failure instead of
        // waiting for every Yahoo host/suffix to fail and returning a blanket 502.
        if(!officialTried){
          officialTried=true;
          const official=await fetchTwseMisIntraday(code,market,attempts);
          if(official)return json(official,200,{"cache-control":"no-store"});
        }
      }
    }
    return json({ok:false,error:'intraday unavailable',attempts},502,{"cache-control":"no-store"});
  }


  if (url.pathname === "/api/history/auto") {
    const code=url.searchParams.get("code")||"3443";
    const market=url.searchParams.get("market")||"";
    const endDate=url.searchParams.get("end_date")||isoDateTaipei();
    const startDate=url.searchParams.get("start_date")||addDaysISO(endDate,-460);
    const fresh=url.searchParams.get("fresh")==="1";

    // Same code/date is requested repeatedly during rescans. Cache the completed
    // merged history at the Worker edge so a second scan does not hit Yahoo/TWSE again.
    const historyCache=caches.default;
    const historyCacheKey=new Request(
      `${url.origin}/__cache/history-auto/${market||"auto"}/${code}/${startDate}/${endDate}/${fresh?"fresh":"normal"}`
    );
    // fresh=1 is used by Scanner/Detail latest-data requests.
    // It must never reuse the 6-hour custom cache, otherwise an intraday
    // request can pin yesterday's final bar after today's close.
    if(!fresh){
      const historyCached=await historyCache.match(historyCacheKey);
      if(historyCached) return historyCached;
    }

    const yahoo=await fetchYahooHistory(code,market,startDate,endDate);
    if(yahoo.ok && yahoo.data.length>=150){
      let data=yahoo.data, freshness={
        merged:0,source:"Yahoo only",last_twse:null,error:null
      };

      // Detail/latest requests explicitly ask for fresh=1.
      // Use exact-date TWSE monthly rows; never infer the exchange date from wall-clock "today".
      if(fresh && market!=="tpex"){
        freshness=await mergeTwseExactRecentBars(code,startDate,endDate,yahoo.data);
        data=freshness.data;
      }

      const body=json({
        ...yahoo,
        data,
        mode:"primary",
        fresh_requested:fresh,
        latest_merge:freshness.source,
        latest_merge_count:freshness.merged||0,
        latest_twse_date:freshness.last_twse||null,
        latest_merge_error:freshness.error||null,
        count:data.length,
        first:data[0]?.date||null,
        last:data.at(-1)?.date||null
      },200,{
        "cache-control":fresh?"no-store":"public,max-age=21600",
        "x-history-cache":fresh?"bypass-fresh":"miss"
      });
      if(!fresh) await historyCache.put(historyCacheKey,body.clone());
      return body;
    }

    if(market!=="tpex"){
      const twse=await fetchTwseMonthlyHistory(code,startDate,endDate);
      if(twse.ok){
        const body=json({...twse,mode:"fallback",latest_merge:"TWSE exact-date monthly",yahoo_attempts:yahoo.attempts,count:twse.data.length,first:twse.data[0]?.date||null,last:twse.data.at(-1)?.date||null},200,{
          "cache-control":fresh?"no-store":"public,max-age=21600",
          "x-history-cache":fresh?"bypass-fresh":"miss"
        });
        if(!fresh) await historyCache.put(historyCacheKey,body.clone());
        return body;
      }
    }

    return json({ok:false,error:"No history source succeeded",yahoo_attempts:yahoo.attempts},502);
  }


  if (url.pathname === "/api/chips/twse") {
    const code=url.searchParams.get("code")||"3443";
    const endDate=url.searchParams.get("end_date")||isoDateTaipei();
    const days=Math.max(1,Math.min(12,Number(url.searchParams.get("days")||12)));
    const dates=recentWeekdays(endDate,days);
    const rows=[];
    // Sequential by date: keeps subrequests bounded and easier on TWSE.
    for(const d of dates){
      rows.push(await chipForDate(code,d));
      await new Promise(r=>setTimeout(r,35));
    }
    const margin=rows.map(x=>x.margin).filter(Boolean).sort((a,b)=>a.date.localeCompare(b.date));
    const inst=rows.map(x=>x.inst).filter(Boolean).sort((a,b)=>a.date.localeCompare(b.date));
    const daytrade=rows.map(x=>x.daytrade).filter(Boolean).sort((a,b)=>a.date.localeCompare(b.date));
    return json({
      ok:true,source:"TWSE official public reports",code,
      requested_days:days,
      margin_count:margin.length,
      institutional_count:inst.length,
      daytrade_count:daytrade.length,
      margin,inst,daytrade,
      diagnostics:rows.map(x=>({date:x.date,margin:!!x.margin,inst:!!x.inst,daytrade:!!x.daytrade,errors:x.errors}))
    });
  }



  if (url.pathname === "/api/finmind/recheck") {
    const code=url.searchParams.get("code")||"3443";
    const endDate=url.searchParams.get("end_date")||isoDateTaipei();
    const startDate=url.searchParams.get("start_date")||addDaysISO(endDate,-140);

    const finmindMode=EFFECTIVE_FINMIND_TOKEN?"token":"anon";
    const cacheKey=new Request(`${url.origin}/__cache/finmind-recheck-r11/${finmindMode}/${code}/${startDate}/${endDate}`);
    const cache=caches.default;
    const cached=await cache.match(cacheKey);
    if(cached) return cached;

    async function ds(dataset){
      const q=new URLSearchParams({dataset,data_id:code,start_date:startDate,end_date:endDate});
      if(EFFECTIVE_FINMIND_TOKEN) q.set("token",EFFECTIVE_FINMIND_TOKEN);
      const u=`https://api.finmindtrade.com/api/v4/data?${q.toString()}`;
      try{
        const r=await fetch(u,{headers:{"accept":"application/json","user-agent":"tw-stock-api/1.7"}});
        const text=await r.text();
        let j=null; try{j=JSON.parse(text)}catch{}
        if(!r.ok || !j || !(j.status===200 || j.status==="200")){
          return {ok:false,count:0,data:[],error:`HTTP ${r.status}`,msg:j?.msg||text.slice(0,180)};
        }
        return {ok:true,count:Array.isArray(j.data)?j.data.length:0,data:Array.isArray(j.data)?j.data:[]};
      }catch(e){
        return {ok:false,count:0,data:[],error:String(e?.message||e)};
      }
    }

    // Sequential requests are deliberate: anonymous FinMind is much more fragile
    // when three datasets are fired simultaneously.
    const margin=await ds("TaiwanStockMarginPurchaseShortSale");
    await new Promise(r=>setTimeout(r,120));
    const inst=await ds("TaiwanStockInstitutionalInvestorsBuySellWide");
    await new Promise(r=>setTimeout(r,120));
    const daytrade=await ds("TaiwanStockDayTrading");

    const complete=[margin,inst,daytrade].filter(x=>x.ok&&x.count>0).length;
    const body={
      ok:complete>0,
      code,
      token:Boolean(env.FINMIND_TOKEN),
      completeness:Math.round(complete/3*100),
      margin,inst,daytrade
    };
    const resp=json(body,complete>0?200:502,{"cache-control":"public, max-age=21600"});
    if(complete>0) await cache.put(cacheKey,resp.clone());
    return resp;
  }

  if (url.pathname === "/api/chips/hybrid") {
    const code=url.searchParams.get("code")||"3443";
    const market=(url.searchParams.get("market")||"").toLowerCase();
    const endDate=url.searchParams.get("end_date")||isoDateTaipei();
    const startDate=url.searchParams.get("start_date")||addDaysISO(endDate,-140);
    const force=url.searchParams.get("force")==="1";

    const finmindMode=EFFECTIVE_FINMIND_TOKEN?"token":"anon";
    const cacheKey=new Request(`${url.origin}/__cache/chips-r11/${finmindMode}/${market||"auto"}/${code}/${startDate}/${endDate}`,request);
    const cache=caches.default;
    if(!force){
      const cached=await cache.match(cacheKey);
      if(cached) return cached;
    }

    async function finmindDataset(dataset){
      const dsKey=new Request(`${url.origin}/__cache/finmind-r11/${finmindMode}/${dataset}/${code}/${startDate}/${endDate}`,request);
      if(!force){
        const hit=await cache.match(dsKey);
        if(hit){ try{return await hit.json()}catch{} }
      }

      const q=new URLSearchParams({dataset,data_id:code,start_date:startDate,end_date:endDate});
      if(EFFECTIVE_FINMIND_TOKEN) q.set("token",EFFECTIVE_FINMIND_TOKEN);
      const u=`https://api.finmindtrade.com/api/v4/data?${q.toString()}`;
      try{
        const r=await fetch(u,{headers:{"accept":"application/json","user-agent":"tw-stock-api/1.17.0-r16"}});
        const text=await r.text(); let j=null; try{j=JSON.parse(text)}catch{}
        const out=(!r.ok || !j || !(j.status===200 || j.status==="200"))
          ? {ok:false,http:r.status,error:`HTTP ${r.status}`,msg:j?.msg||text.slice(0,180),data:[]}
          : {ok:true,http:r.status,data:Array.isArray(j.data)?j.data:[]};
        const ttl=out.ok?21600:900;
        try{await cache.put(dsKey,new Response(JSON.stringify(out),{headers:{
          "content-type":"application/json;charset=UTF-8","cache-control":`public,max-age=${ttl}`
        }}))}catch{}
        return out;
      }catch(e){return {ok:false,http:0,error:String(e?.message||e),data:[]}}
    }

    function institutionalStandardToWide(rows){
      const map=new Map();
      for(const r of rows||[]){
        const date=r?.date; if(!date) continue;
        if(!map.has(date)) map.set(date,{date,stock_id:String(code),
          Foreign_Investor_buy:0,Foreign_Investor_sell:0,
          Foreign_Dealer_Self_buy:0,Foreign_Dealer_Self_sell:0,
          Investment_Trust_buy:0,Investment_Trust_sell:0,
          Dealer_buy:0,Dealer_sell:0,Dealer_self_buy:0,Dealer_self_sell:0,
          Dealer_Hedging_buy:0,Dealer_Hedging_sell:0});
        const o=map.get(date), name=String(r.name||"").toLowerCase();
        const buy=Number(r.buy)||0,sell=Number(r.sell)||0;
        if(name.includes("foreign_dealer")){o.Foreign_Dealer_Self_buy+=buy;o.Foreign_Dealer_Self_sell+=sell}
        else if(name.includes("foreign")){o.Foreign_Investor_buy+=buy;o.Foreign_Investor_sell+=sell}
        else if(name.includes("investment_trust")){o.Investment_Trust_buy+=buy;o.Investment_Trust_sell+=sell}
        else if(name.includes("dealer_hedg")||name.includes("hedg")){o.Dealer_Hedging_buy+=buy;o.Dealer_Hedging_sell+=sell}
        else if(name.includes("dealer_self")||name.includes("dealer-self")){o.Dealer_self_buy+=buy;o.Dealer_self_sell+=sell}
        else if(name.includes("dealer")){o.Dealer_buy+=buy;o.Dealer_sell+=sell}
      }
      return [...map.values()].sort((a,b)=>a.date.localeCompare(b.date));
    }

    let margin=[],inst=[],daytrade=[];
    const source_detail={margin:null,inst:null,daytrade:null};
    const diagnostics=[];

    if(market==="twse"){
      // Market-wide reports: validate Target date only here. R6's 12×3 upstream
      // requests in one hybrid call were too heavy and could surface platform HTML errors.
      const rows=[await chipForDate(code,endDate)];
      margin=rows.map(x=>x.margin).filter(Boolean);
      inst=rows.map(x=>x.inst).filter(Boolean);
      daytrade=rows.map(x=>x.daytrade).filter(Boolean);
      if(margin.length) source_detail.margin="TWSE latest";
      if(inst.length) source_detail.inst="TWSE latest";
      if(daytrade.length) source_detail.daytrade="TWSE latest";
      diagnostics.push(...rows.filter(x=>x.errors?.length).map(x=>({date:x.date,errors:x.errors})));
    }

    async function fillMargin(){
      const officialLatest=margin.at(-1)||null;
      const r=await finmindDataset("TaiwanStockMarginPurchaseShortSale");
      diagnostics.push({dataset:"TaiwanStockMarginPurchaseShortSale",ok:r.ok,http:r.http,count:r.data?.length||0,msg:r.msg||r.error||null});
      if(r.ok&&r.data?.length){
        margin=r.data.sort((a,b)=>String(a.date).localeCompare(String(b.date)));
        if(officialLatest){
          margin=margin.filter(x=>String(x.date)!==String(officialLatest.date)).concat([officialLatest]).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
          source_detail.margin="FinMind hist + TWSE latest";
        }else source_detail.margin="FinMind";
      }
    }
    async function fillInst(){
      const officialLatest=inst.at(-1)||null;
      let r=await finmindDataset("TaiwanStockInstitutionalInvestorsBuySellWide");
      diagnostics.push({dataset:"TaiwanStockInstitutionalInvestorsBuySellWide",ok:r.ok,http:r.http,count:r.data?.length||0,msg:r.msg||r.error||null});
      if(r.ok&&r.data?.length){
        inst=r.data.sort((a,b)=>String(a.date).localeCompare(String(b.date)));
        if(officialLatest){
          inst=inst.filter(x=>String(x.date)!==String(officialLatest.date)).concat([officialLatest]).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
          source_detail.inst="FinMind Wide hist + TWSE latest";
        }else source_detail.inst="FinMind Wide";
        return;
      }
      r=await finmindDataset("TaiwanStockInstitutionalInvestorsBuySell");
      diagnostics.push({dataset:"TaiwanStockInstitutionalInvestorsBuySell",ok:r.ok,http:r.http,count:r.data?.length||0,msg:r.msg||r.error||null});
      const wide=institutionalStandardToWide(r.data||[]);
      if(r.ok&&wide.length){
        inst=wide;
        if(officialLatest){
          inst=inst.filter(x=>String(x.date)!==String(officialLatest.date)).concat([officialLatest]).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
          source_detail.inst="FinMind Std hist + TWSE latest";
        }else source_detail.inst="FinMind Standard→Wide";
      }
    }
    async function fillDaytrade(){
      const officialLatest=daytrade.at(-1)||null;
      const r=await finmindDataset("TaiwanStockDayTrading");
      diagnostics.push({dataset:"TaiwanStockDayTrading",ok:r.ok,http:r.http,count:r.data?.length||0,msg:r.msg||r.error||null});
      if(r.ok&&r.data?.length){
        daytrade=r.data.sort((a,b)=>String(a.date).localeCompare(String(b.date)));
        if(officialLatest){
          daytrade=daytrade.filter(x=>String(x.date)!==String(officialLatest.date)).concat([officialLatest]).sort((a,b)=>String(a.date).localeCompare(String(b.date)));
          source_detail.daytrade="FinMind hist + TWSE latest";
        }else source_detail.daytrade="FinMind";
      }
    }

    await fillMargin();

    // Manual Analyze needs a real financing history, not merely one latest point.
    if(force && market==="twse" && margin.length<5){
      const dates=recentWeekdays(endDate,20);
      const officialRows=[];
      const concurrency=4;
      for(let i=0;i<dates.length;i+=concurrency){
        const batch=dates.slice(i,i+concurrency);
        const got=await Promise.all(batch.map(d=>marginForDate(code,d)));
        officialRows.push(...got.filter(Boolean));
      }
      if(officialRows.length){
        const byDate=new Map();
        for(const r of margin) byDate.set(String(r.date),r);
        for(const r of officialRows) byDate.set(String(r.date),r);
        margin=[...byDate.values()].sort((a,b)=>String(a.date).localeCompare(String(b.date)));
        source_detail.margin=(source_detail.margin?source_detail.margin+" + ":"")+"TWSE official history";
        diagnostics.push({dataset:"TWSE MI_MARGN history fallback",ok:true,count:officialRows.length});
      }else diagnostics.push({dataset:"TWSE MI_MARGN history fallback",ok:false,count:0});
    }

    await fillInst();
    await fillDaytrade();

    // R16: "missing" margin balance must stay missing, never become numeric 0.
    // Explicit 0 is still valid; null/undefined/''/'--' are removed.
    margin=margin.filter(r=>cleanNum(r?.MarginPurchaseTodayBalance)!==null);

    const flags={margin:margin.length>0,inst:inst.length>0,daytrade:daytrade.length>0};
    const history_ready={margin:margin.length>=5,inst:inst.length>=5,daytrade:daytrade.length>=5};
    const available=Object.values(flags).filter(Boolean).length;
    const body={
      ok:available>0,code,market,
      source:"TWSE + FinMind assist",
      source_detail,
      completeness:Math.round(available/3*100),
      completeness_detail:flags,
      history_ready,
      coverage_days:{margin:margin.length,inst:inst.length,daytrade:daytrade.length},
      margin,inst,daytrade,
      data_dates:{
        margin:margin.at(-1)?.date||null,
        inst:inst.at(-1)?.date||null,
        daytrade:daytrade.at(-1)?.date||null
      },
      finmind_assist:Object.values(source_detail).some(v=>String(v||"").startsWith("FinMind")),
      refresh_mode:force?"forced-upstream":"cache-allowed",
      finmind_mode:EFFECTIVE_FINMIND_TOKEN?"token":"anonymous",
      diagnostics
    };
    const resp=json(body,200,{"cache-control":"public,max-age=900"});
    await cache.put(cacheKey,resp.clone());
    return resp;
  }


  // ===== R17 Strategy Research Cache APIs =====
  // status/load are guaranteed cache-only: they never call Yahoo/TWSE/TPEx/FinMind.
  if (url.pathname === "/api/research/cache/status") {
    const code=String(url.searchParams.get("code")||"").trim();
    const market=String(url.searchParams.get("market")||"").toLowerCase();
    const startDate=String(url.searchParams.get("start_date")||"");
    const endDate=String(url.searchParams.get("end_date")||"");
    if(!code) return json({ok:false,error:"code is required"},400,{"cache-control":"no-store"});
    const p=await readResearchCache(url.origin,code,market);
    return json({ok:true,code,market,hit:Boolean(p),coverage_ok:researchCoverageOK(p,startDate,endDate),
      coverage_start:p?.coverage_start||null,coverage_end:p?.coverage_end||null,cached_at:p?.cached_at||null,
      history_count:p?.history?.length||0,margin_count:p?.chips?.margin?.length||0,
      inst_count:p?.chips?.inst?.length||0,daytrade_count:p?.chips?.daytrade?.length||0,
      completeness:p?.completeness??null
    },200,{"cache-control":"no-store"});
  }

  if (url.pathname === "/api/research/cache/status-bulk") {
    if(request.method!=="POST") return json({ok:false,error:"POST required"},405,{"cache-control":"no-store"});
    let body={}; try{body=await request.json()}catch{}
    const stocks=Array.isArray(body?.stocks)?body.stocks.slice(0,800):[];
    const startDate=String(body?.start_date||"");
    const endDate=String(body?.end_date||"");
    const data=[];
    for(const s of stocks){
      const code=String(s?.code||"").trim(),market=String(s?.market||"").toLowerCase();
      if(!code)continue;
      const p=await readResearchCache(url.origin,code,market);
      data.push({code,market,hit:Boolean(p),coverage_ok:researchCoverageOK(p,startDate,endDate),
        coverage_start:p?.coverage_start||null,coverage_end:p?.coverage_end||null,cached_at:p?.cached_at||null,
        history_count:p?.history?.length||0,completeness:p?.completeness??null});
    }
    const ready=data.filter(x=>x.coverage_ok).length;
    return json({ok:true,count:data.length,ready,need_build:data.length-ready,data},200,{"cache-control":"no-store"});
  }

  if (url.pathname === "/api/research/cache/load") {
    const code=String(url.searchParams.get("code")||"").trim();
    const market=String(url.searchParams.get("market")||"").toLowerCase();
    const startDate=String(url.searchParams.get("start_date")||"");
    const endDate=String(url.searchParams.get("end_date")||"");
    if(!code) return json({ok:false,error:"code is required"},400,{"cache-control":"no-store"});
    const p=await readResearchCache(url.origin,code,market);
    if(!p) return json({ok:false,cache_only:true,cache_miss:true,error:"Research cache missing. Build cache explicitly first."},404,{"cache-control":"no-store"});
    if(!researchCoverageOK(p,startDate,endDate)) return json({ok:false,cache_only:true,coverage_miss:true,
      coverage_start:p.coverage_start,coverage_end:p.coverage_end,error:"Research cache does not cover requested period."},409,{"cache-control":"no-store"});
    const inRange=rows=>(rows||[]).filter(r=>String(r?.date||"")>=startDate&&String(r?.date||"")<=endDate);
    return json({ok:true,cache_only:true,token_used:false,code,market,
      coverage_start:p.coverage_start,coverage_end:p.coverage_end,cached_at:p.cached_at,
      completeness:p.completeness??null,
      history:inRange(p.history),chips:{margin:inRange(p.chips?.margin),inst:inRange(p.chips?.inst),daytrade:inRange(p.chips?.daytrade)}
    },200,{"cache-control":"no-store"});
  }

  if (url.pathname === "/api/research/cache/build") {
    if(request.method!=="POST") return json({ok:false,error:"POST required"},405,{"cache-control":"no-store"});
    let body={}; try{body=await request.json()}catch{}
    const code=String(body?.code||"").trim(),market=String(body?.market||"").toLowerCase();
    const startDate=String(body?.start_date||"");
    const endDate=String(body?.end_date||"");
    if(!/^\d{4,6}[A-Za-z]?$/.test(code)||!startDate||!endDate) return json({ok:false,error:"code/start_date/end_date required"},400,{"cache-control":"no-store"});

    const old=await readResearchCache(url.origin,code,market);
    if(researchCoverageOK(old,startDate,endDate)){
      return json({ok:true,code,market,cache_hit:true,upstream_used:false,token_may_have_been_used:false,
        coverage_start:old.coverage_start,coverage_end:old.coverage_end,cached_at:old.cached_at,
        history_count:old.history?.length||0,completeness:old.completeness??null
      },200,{"cache-control":"no-store"});
    }

    const ranges=[];
    if(!old){ ranges.push([startDate,endDate]); }
    else{
      if(startDate<old.coverage_start) ranges.push([startDate,addDaysISO(old.coverage_start,-1)]);
      if(endDate>old.coverage_end) ranges.push([addDaysISO(old.coverage_end,1),endDate]);
    }
    let history=old?.history||[], margin=old?.chips?.margin||[], inst=old?.chips?.inst||[], daytrade=old?.chips?.daytrade||[];
    const diagnostics=[];
    let anyHistory=false, anyChipCall=false, bestCompleteness=Number(old?.completeness)||0;

    for(const [rs,re] of ranges){
      if(rs>re) continue;
      const hp=`/api/history/auto?code=${encodeURIComponent(code)}&market=${encodeURIComponent(market)}&start_date=${rs}&end_date=${re}`;
      const hr=await callOwnApiJSON(hp,request,env,url.origin);
      const hrows=hr.body?.data||hr.body?.prices||[];
      if(hr.ok&&Array.isArray(hrows)&&hrows.length){history=mergeDateRows(history,hrows);anyHistory=true;}
      diagnostics.push({range:[rs,re],history_ok:hr.ok&&Array.isArray(hrows)&&hrows.length>0,history_count:hrows?.length||0});

      const cp=`/api/chips/hybrid?code=${encodeURIComponent(code)}&market=${encodeURIComponent(market)}&start_date=${rs}&end_date=${re}`;
      const cr=await callOwnApiJSON(cp,request,env,url.origin);
      anyChipCall=true;
      if(cr.ok&&cr.body){
        margin=mergeDateRows(margin,cr.body.margin||[]);
        inst=mergeDateRows(inst,cr.body.inst||[]);
        daytrade=mergeDateRows(daytrade,cr.body.daytrade||[]);
        bestCompleteness=Math.max(bestCompleteness,Number(cr.body.completeness)||0);
      }
      diagnostics[diagnostics.length-1].chips_ok=cr.ok;
      diagnostics[diagnostics.length-1].chips_completeness=Number(cr.body?.completeness)||0;
    }

    // A previous cache may contain history even when every extension failed.
    // Publish coverage atomically only after all requested ranges succeeded.
    // Keep the old cache intact on failure so an explicit build can retry.
    const failedRanges=diagnostics.filter(d=>!d.history_ok||!d.chips_ok||d.chips_completeness!==100);
    if(failedRanges.length) return json({ok:false,code,market,incomplete:true,
      cache_preserved:Boolean(old),coverage_start:old?.coverage_start||null,coverage_end:old?.coverage_end||null,
      error:"Research data is incomplete; coverage was not extended. Retry build explicitly after the sources recover.",
      diagnostics,failed_ranges:failedRanges.map(d=>d.range)
    },502,{"cache-control":"no-store"});
    if(!history.length) return json({ok:false,code,market,error:"Unable to build research cache: no history data",diagnostics},502,{"cache-control":"no-store"});
    const coverageStart=old?String(old.coverage_start<startDate?old.coverage_start:startDate):startDate;
    const coverageEnd=old?String(old.coverage_end>endDate?old.coverage_end:endDate):endDate;
    const payload={version:1,code,market,coverage_start:coverageStart,coverage_end:coverageEnd,
      cached_at:new Date().toISOString(),history,chips:{margin,inst,daytrade},completeness:bestCompleteness,diagnostics};
    await writeResearchCache(url.origin,payload);
    return json({ok:true,code,market,cache_hit:false,upstream_used:true,
      // We cannot know the provider's exact accounting, so never claim an exact token-call count.
      token_may_have_been_used:anyChipCall&&Boolean(EFFECTIVE_FINMIND_TOKEN),
      ranges_fetched:ranges,coverage_start:coverageStart,coverage_end:coverageEnd,cached_at:payload.cached_at,
      history_count:history.length,margin_count:margin.length,inst_count:inst.length,daytrade_count:daytrade.length,
      completeness:bestCompleteness,diagnostics
    },200,{"cache-control":"no-store"});
  }

  if (url.pathname === "/api/finmind/token-store") {
    const cache=caches.default;
    const slot=new Request(`${url.origin}/__private/finmind-token-slot-v1`,{method:"GET"});

    if(request.method==="POST"){
      let body={};
      try{body=await request.json()}catch{}
      const token=String(body?.token||"").trim();
      if(!token) return json({ok:false,error:"token is required"},400,{"cache-control":"no-store"});

      const savedAt=Date.now();
      const expiresAt=savedAt+7*24*60*60*1000;
      const payload={token,saved_at:savedAt,expires_at:expiresAt};
      await cache.put(slot,new Response(JSON.stringify(payload),{
        headers:{
          "content-type":"application/json;charset=UTF-8",
          "cache-control":"public,max-age=604800"
        }
      }));
      return json({
        ok:true,
        saved:true,
        storage:"worker-cache",
        expires_at:new Date(expiresAt).toISOString()
      },200,{"cache-control":"no-store"});
    }

    if(request.method==="DELETE"){
      await cache.delete(slot);
      return json({ok:true,cleared:true},200,{"cache-control":"no-store"});
    }

    return json({ok:false,error:"Method not allowed"},405,{"cache-control":"no-store"});
  }

  if (url.pathname === "/api/finmind/status") {
    const configured=Boolean(EFFECTIVE_FINMIND_TOKEN);
    let saved=false,expires_at=null;
    try{
      const slot=new Request(`${url.origin}/__private/finmind-token-slot-v1`,{method:"GET"});
      const hit=await caches.default.match(slot);
      if(hit){
        const p=await hit.json();
        if(Number(p?.expires_at)>Date.now()){
          saved=true;
          expires_at=new Date(Number(p.expires_at)).toISOString();
        }
      }
    }catch{}
    const browserAuth=/^Bearer\s+/i.test(String(request.headers.get("authorization")||""));
    return json({
      ok:true,
      configured,
      mode:configured?"token":"anonymous",
      source:browserAuth?"browser":(env.FINMIND_TOKEN?"worker-secret":(saved?"server-saved":"anonymous")),
      server_saved:saved,
      expires_at,
      note:configured
        ?"FinMind Token 可用。"
        :"未收到瀏覽器 Token、Worker Secret 或伺服器暫存 Token。"
    },200,{"cache-control":"no-store"});
  }

  if (url.pathname === "/api/finmind") {
    const dataset = url.searchParams.get("dataset") || "TaiwanStockPrice";
    const dataId = url.searchParams.get("data_id") || "";
    const startDate = url.searchParams.get("start_date") || "";
    const endDate = url.searchParams.get("end_date") || "";

    if (!dataset) return json({ ok:false, error:"dataset is required" }, 400);
    if (!dataId && dataset !== "TaiwanStockInfo") {
      return json({ ok:false, error:"data_id is required for this proxy endpoint" }, 400);
    }

    const q = new URLSearchParams({ dataset });
    if (dataId) q.set("data_id", dataId);
    if (startDate) q.set("start_date", startDate);
    if (endDate) q.set("end_date", endDate);
    if (env.FINMIND_TOKEN) q.set("token", env.FINMIND_TOKEN);

    const upstream = `https://api.finmindtrade.com/api/v4/data?${q.toString()}`;
    try {
      const raw = await fetchJson(upstream);
      return json({
        ok: raw.status === 200 || raw.status === "200",
        source: "FinMind",
        dataset,
        data_id: dataId || null,
        msg: raw.msg ?? null,
        count: Array.isArray(raw.data) ? raw.data.length : 0,
        data: raw.data ?? [],
      });
    } catch (e) {
      return json({ ok:false, source:"FinMind", error:String(e.message || e) }, 502);
    }
  }

  return json({ ok:false, error:"Unknown API route", path:url.pathname }, 404);
}

async function requestFinMindToken(request,env,origin){
  const auth=String(request.headers.get("authorization")||"");
  const m=auth.match(/^Bearer\s+(.+)$/i);
  const browserToken=(m?.[1]||"").trim();
  if(browserToken) return browserToken;

  const secret=String(env?.FINMIND_TOKEN||"").trim();
  if(secret) return secret;

  try{
    const slot=new Request(`${origin}/__private/finmind-token-slot-v1`,{method:"GET"});
    const hit=await caches.default.match(slot);
    if(!hit) return "";
    const p=await hit.json();
    if(Number(p?.expires_at)<=Date.now()){
      await caches.default.delete(slot);
      return "";
    }
    return String(p?.token||"").trim();
  }catch{
    return "";
  }
}

export default {
  async fetch(request, env) {
    const url = new URL(request.url);

    if (url.pathname.startsWith("/api/")) {
      return routeApi(request, env, url);
    }

    if (env.ASSETS) {
      const asset = await env.ASSETS.fetch(request);
      const path = new URL(request.url).pathname;
      if (path.endsWith(".html") || path === "/" || path === "/scanner.html" || path === "/detail.html" || path === "/scanner" || path === "/detail") {
        const headers = new Headers(asset.headers);
        headers.set("Cache-Control","no-store, no-cache, must-revalidate, max-age=0");
        headers.set("Pragma","no-cache");
        headers.set("Expires","0");
        headers.set("X-App-Version","1.17.0-R21");
        return new Response(asset.body,{status:asset.status,statusText:asset.statusText,headers});
      }
      return asset;
    }
    return new Response("Static assets binding is missing.", { status: 500 });
  }
};
